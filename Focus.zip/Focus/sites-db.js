/* ==== База сайтов: точечные переопределения.
   Только перечисленные здесь меняются, остальные — стандарт
   (подложка 40%, фавикон как пришел).
   Ключ — домен (без www, маленькими). Поиск идет от полного хоста вверх:
   music.yandex.ru -> yandex.ru.
   bg: фон плитки. icon: ширина иконки в пикселях (высота по пропорции).
   fit: 'long' — подгонять по длинной стороне (для неквадратных).
   Файл общий для Фокуса и Фокус+. ==== */
var SITES_DB = {
  'twitch.tv': { bg: '#FFFFFF', icon: 38, fit: 'long', name: 'Twitch' },
  'github.com': { bg: '#FFFFFF', icon: 38, fit: 'long', name: 'GitHub' },
  'youtube.com': { bg: '#FFFFFF', icon: 42, name: 'YouTube' },
  'youtu.be': { bg: '#FFFFFF', icon: 42, name: 'YouTube' },
  'pinterest.com': { bg: '#FFFFFF', icon: 42 },
  'iimg.su': { bg: '#FFFFFF', icon: 42 },
  'eblo.id': { bg: '#FFFFFF', icon: 42 },
  'l3payy.github.io': { bg: '#000000', icon: 42 },
  'kick.com': { bg: '#000000', icon: 42 },
  'gemini.google.com': { bg: '#FFFFFF', icon: 42 }
};
