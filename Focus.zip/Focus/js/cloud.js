
(function () {
  'use strict';
  var toast = function (m) {
    try { window.top.__focusToast(m); } catch (e) {}
  };
  var chromeDim = function (on) {
    try { window.top.setChromeDim(on); } catch (e) {}
  };

  /* ---- Тема и провайдер из настроек ---- */
  var THEME = 'lilac';
  try { THEME = localStorage.getItem('focus:theme') || 'lilac'; } catch (e) {}
  document.querySelectorAll('[data-theme-icon]').forEach(function (img) {
    img.src = 'icon/' + THEME + '/' + img.getAttribute('data-theme-icon') + '.svg';
  });
  function searchProvider() {
    try {
      return localStorage.getItem('focus:search:cloud')
        || localStorage.getItem('focus:search')
        || 'google';
    } catch (e) { return 'google'; }
  }
  var PROVIDER_ICON = { yandex: 'icon/yandex.svg', google: 'icon/google.svg' };
  function refreshProviderIcon() {
    document.querySelectorAll('[data-provider-icon]').forEach(function (img) {
      img.src = PROVIDER_ICON[searchProvider()] || PROVIDER_ICON.google;
    });
  }
  refreshProviderIcon();
  // Оболочка дергает при переходе на Облачка (фрейм живет дальше).
  window.__refreshProvider = refreshProviderIcon;
  window.addEventListener('storage', function (e) {
    if (e.key === 'focus:search' || e.key === 'focus:search:cloud') refreshProviderIcon();
    if (e.key === 'focus:theme') {
      try { document.documentElement.dataset.theme = localStorage.getItem('focus:theme') || 'lilac'; } catch (err) {}
      drawColorCache = null;
      renderDraw();
    }
  });

  /* ---- Поиск ---- */
  var box = document.querySelector('[data-search-box]');
  var input = document.querySelector('[data-search]');
  var goBtn = document.querySelector('[data-search-go]');
  function doSearch() {
    if (!input.value.trim()) return;
    var q = encodeURIComponent(input.value.trim());
    window.top.location.href = searchProvider() === 'yandex'
      ? 'https://ya.ru/search/?text=' + q
      : 'https://www.google.com/search?q=' + q;
  }
  box.addEventListener('mousedown', function (e) {
    if (e.target === input || e.target === goBtn) return;
    e.preventDefault();
    input.focus();
  });
  input.addEventListener('focus', function () { box.classList.add('open'); });
  input.addEventListener('blur', function () {
    if (!input.value.trim()) box.classList.remove('open');
  });
  input.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') doSearch();
    if (e.key === 'Escape') { input.value = ''; input.blur(); }
  });
  goBtn.addEventListener('mousedown', function (e) { e.preventDefault(); });
  goBtn.addEventListener('click', doSearch);

  /* ---- Клавиатура и ПКМ — наружу в оболочку ---- */
  window.addEventListener('keydown', function (e) {
    if (drawMode) {
      if (e.key === 'Escape') exitDraw(false);
      return;
    }
    var inField = e.target.closest('input, textarea, [contenteditable]');
    if (e.key === 'Escape' && modal && !modal.hidden) { closeModal(); return; }
    if (e.key === 'Escape' && confirmModal && !confirmModal.hidden) { hideConfirm(); return; }
    if (e.key === 'Escape' && cardMenu && !cardMenu.hidden) { hideCardMenu(); return; }
    if (e.key === 'Escape' && textMenu && !textMenu.hidden) { hideTextMenu(); return; }
    if (e.key === 'Escape' && e.target.closest && e.target.closest('.cloud-text.editing')) { e.target.blur(); return; }
    if (inField) return;
    if (e.key === 'PageDown' || e.key === 'ArrowDown') { e.preventDefault(); top.nav(1); }
    if (e.key === 'PageUp' || e.key === 'ArrowUp') { e.preventDefault(); top.nav(-1); }
  });
  window.addEventListener('contextmenu', function (e) {
    // В правке текста — нативное меню браузера.
    if (e.target.closest('.cloud-text.editing')) return;
    var txt = e.target.closest('.cloud-text');
    if (txt) {
      e.preventDefault();
      if (drag) return;
      openTextMenu(e.clientX, e.clientY, txt);
      return;
    }
    var card = e.target.closest('.cloud-card');
    if (card) {
      e.preventDefault();
      if (drag) return;
      openCardMenu(e.clientX, e.clientY, card);
      return;
    }
    if (e.target.closest('img, canvas, input, textarea, a, button, .search, .paste-modal')) return;
    e.preventDefault();
    hideCardMenu();
    var r = window.frameElement ? window.frameElement.getBoundingClientRect() : { left: 0, top: 0 };
    top.openCtx(e.clientX + r.left, e.clientY + r.top);
  });
  window.addEventListener('mousedown', function (e) {
    try { top.closeCtx(); } catch (err) {}
    if (cardMenu && !cardMenu.hidden && !cardMenu.contains(e.target)) hideCardMenu();
    if (textMenu && !textMenu.hidden && !textMenu.contains(e.target)) hideTextMenu();
  });

  /* ---- Картинки: мета в localStorage, блобы в IndexedDB ---- */
  var LS_KEY = 'focus:cloudItems';
  var MAX_SIDE = 900;   // храним до 900 по длинной стороне...
  var SHOW_SIDE = 300;  // ...а показываем не шире 300
  var MAX_ITEMS = 100;
  var Z_BASE = 10;
  var objectUrls = [];
  var modal = null, previewImg = null, linkInput = null, scrim = null;
  var pendingFile = null, pendingUrl = null;

  function loadMeta() {
    try { return JSON.parse(localStorage.getItem(LS_KEY)) || []; }
    catch (e) { return []; }
  }
  function saveMeta(items) {
    try { localStorage.setItem(LS_KEY, JSON.stringify(items)); } catch (e) {}
  }
  function normalizeUrl(v) {
    v = (v || '').trim();
    if (!v) return '';
    if (!/^[a-z]+:\/\//i.test(v)) v = 'https://' + v;
    return /^https?:\/\/.+/.test(v) ? v : '';
  }
  // Только растр без анимаций: PNG, JPEG, WebP. GIF/BMP/AVIF/SVG — мимо.
  function isSupportedImage(t) {
    return t === 'image/png' || t === 'image/jpeg' || t === 'image/jpg' || t === 'image/webp';
  }
function idb() {
  // Один коннект на документ: иначе копятся открытые и блокируют апгрейды.
  if (!idb._p) {
    idb._p = new Promise(function (resolve, reject) {
      // Версия единая на весь проект (2): даунгрейд-открытие браузер режет VersionError.
      var req = indexedDB.open('focus-db', 2);
      req.onupgradeneeded = function () {
        if (!req.result.objectStoreNames.contains('images')) req.result.createObjectStore('images');
        if (!req.result.objectStoreNames.contains('backgrounds')) req.result.createObjectStore('backgrounds');
      };
      req.onsuccess = function () {
        var db = req.result;
        db.onversionchange = function () { db.close(); idb._p = null; };
        resolve(db);
      };
      req.onerror = function () { idb._p = null; reject(req.error); };
      req.onblocked = function () { idb._p = null; reject(new Error('idb blocked')); };
    });
  }
  return idb._p;
  }
  function idbReq(db, mode, fn) {
    return new Promise(function (resolve, reject) {
      var tx = db.transaction('images', mode);
      tx.onabort = function () { reject(tx.error || new Error('tx abort')); };
      tx.onerror = function () { reject(tx.error || new Error('tx error')); };
      var rq = fn(tx.objectStore('images'));
      rq.onsuccess = function () { resolve(rq.result); };
      rq.onerror = function () { reject(rq.error); };
    });
  }
  function fileToBitmap(file) {
    if (window.createImageBitmap) {
      try { return createImageBitmap(file).catch(function () { return bitmapViaImg(file); }); }
      catch (e) { return bitmapViaImg(file); }
    }
    return bitmapViaImg(file);
  }
  function bitmapViaImg(file) {
    var url = URL.createObjectURL(file);
    return new Promise(function (res, rej) {
      var i = new Image();
      i.onload = function () {
        if (window.createImageBitmap) {
          createImageBitmap(i).then(
            function (b) { URL.revokeObjectURL(url); res(b); },
            function (e) { URL.revokeObjectURL(url); rej(e); }
          );
        } else rej(new Error('no bitmap'));
      };
      i.onerror = function () { URL.revokeObjectURL(url); rej(new Error('img')); };
      i.src = url;
    });
  }
  function processImage(file) {
    return fileToBitmap(file).then(function (bmp) {
      try {
        var s = Math.min(1, MAX_SIDE / Math.max(bmp.width, bmp.height));
        var w = Math.max(1, Math.round(bmp.width * s));
        var h = Math.max(1, Math.round(bmp.height * s));
        var c = document.createElement('canvas');
        c.width = w;
        c.height = h;
        c.getContext('2d').drawImage(bmp, 0, 0, w, h);
        return new Promise(function (res) { c.toBlob(res, 'image/webp', 0.85); })
          .then(function (blob) { return { blob: blob || file, w: w, h: h }; });
      } finally { if (bmp.close) bmp.close(); }
    });
  }
  function uid() {
    return 'img_' + Date.now().toString(36) + Math.floor(Math.random() * 1e6).toString(36);
  }
  function randomRot() {
    // Наклон ±1..7 градусов, нуля не бывает.
    return Math.round((Math.random() < 0.5 ? -1 : 1) * (1 + Math.random() * 6) * 10) / 10;
  }
  function cardEl(meta, url) {
    var el = document.createElement(meta.link ? 'a' : 'div');
    el.className = 'cloud-card';
    el.dataset.id = meta.id;
    if (meta.link) { el.href = meta.link; el.target = '_top'; } // вся вкладка, не фрейм
    el.style.left = (meta.x * 100) + '%';
    el.style.top = (meta.y * 100) + '%';
    el.style.zIndex = String(meta.z);
    el.style.setProperty('--rot', meta.rot + 'deg');
    // Ширина показа из длинной стороны: layout от картинки не зависит.
    el.style.width = dispSize(meta).w + 'px';
    var img = document.createElement('img');
    img.className = 'cloud-img';
    img.addEventListener('load', function () { img.classList.add('ok'); }, { once: true });
    img.src = url;
    img.draggable = false;
    img.decoding = 'async';
    el.appendChild(img);
    var hover = document.createElement('div');
    hover.className = 'card-hover';
    var hoverImg = document.createElement('img');
    hoverImg.src = 'icon/hoverImage.svg';
    hoverImg.alt = '';
    hoverImg.draggable = false;
    hover.appendChild(hoverImg);
    el.appendChild(hover);
    return el;
  }
  // Подсказка «Можно двигать»: 3 секунды курсор на карточке.
  var hintTimers = {};
  function clearHintTimer(id) {
    clearTimeout(hintTimers[id]);
    delete hintTimers[id];
  }
  document.body.addEventListener('mouseover', function (e) {
    var card = e.target && e.target.closest ? e.target.closest('.cloud-card') : null;
    if (!card || card.dataset.hintArmed) return;
    card.dataset.hintArmed = '1';
    (function (c) {
      hintTimers[c.dataset.id] = setTimeout(function () { c.classList.add('hint'); }, 3000);
    })(card);
  });
  document.body.addEventListener('mouseout', function (e) {
    var card = e.target && e.target.closest ? e.target.closest('.cloud-card') : null;
    if (!card) return;
    if (card.contains(e.relatedTarget)) return;
    delete card.dataset.hintArmed;
    clearHintTimer(card.dataset.id);
    card.classList.remove('hint');
  });
  /* ---- Текст-заметки: создание, правка на месте, лимит 50 ---- */
  var TEXT_MAX = 50;
  function textEl(meta) {
    var el = document.createElement('div');
    el.className = 'cloud-text';
    el.dataset.id = meta.id;
    el.contentEditable = 'true';
    el.spellcheck = false;
    el.textContent = meta.text || '';
    el.style.left = (meta.x * 100) + '%';
    el.style.top = (meta.y * 100) + '%';
    el.style.zIndex = String(meta.z);
    el.style.setProperty('--rot', meta.rot + 'deg');
    return el;
  }
  function applyText(node) {
    node.classList.remove('editing');
    var txt = node.textContent || '';
    if (txt.length > TEXT_MAX) { txt = txt.slice(0, TEXT_MAX); node.textContent = txt; }
    var f = metaById(node.dataset.id);
    if (!f) { node.remove(); return; }
    if (!txt.trim()) {
      node.remove();
      saveMeta(f.all.filter(function (a) { return a.id !== f.m.id; }));
      return;
    }
    if (f.m.text !== txt) { f.m.text = txt; saveMeta(f.all); }
  }
  window.addCloudText = function () {
    if (loadMeta().length >= MAX_ITEMS) { toast('Облачка полны — максимум 100'); return; }
    var spot = findSpotBox(220, 60);
    var items = loadMeta();
    var meta = {
      id: uid(), kind: 'text', text: '',
      x: spot.x, y: spot.y, rot: randomRot(),
      z: Z_BASE + (items.length % MAX_ITEMS)
    };
    saveMeta(items.concat([meta]));
    var node = textEl(meta);
    document.body.appendChild(node);
    node.classList.add('editing');
    node.focus();
    // Замер реальных габаритов для анти-наложения следующих.
    requestAnimationFrame(function () {
      var all = loadMeta(), f = null;
      for (var k = 0; k < all.length; k++) {
        if (all[k].id === meta.id) { f = all[k]; break; }
      }
      if (f) {
        f.w = Math.round(node.offsetWidth);
        f.h = Math.round(node.offsetHeight);
        saveMeta(all);
      }
    });
  };
  // Лимит символов прямо при вводе.
  document.body.addEventListener('input', function (e) {
    var t = e.target.closest ? e.target.closest('.cloud-text') : null;
    if (!t || (t.textContent || '').length <= TEXT_MAX) return;
    t.textContent = (t.textContent || '').slice(0, TEXT_MAX);
    var r = document.createRange();
    r.selectNodeContents(t);
    r.collapse(false);
    var s = window.getSelection();
    s.removeAllRanges();
    s.addRange(r);
  });
  // Применить при потере фокуса.
  document.body.addEventListener('focusout', function (e) {
    var t = e.target.closest ? e.target.closest('.cloud-text.editing') : null;
    if (t) applyText(t);
  });
  // Клик по пустому — применить (capture: раньше drag-логики).
  document.body.addEventListener('mousedown', function (e) {
    var ed = document.querySelector('.cloud-text.editing');
    if (ed && !ed.contains(e.target)) ed.blur();
  }, true);
  // Перетаскивание: текст сразу, картинка с хинтом. Клик — править, ведение — двигать.
  var drag = null, dragEndTime = 0, pendingTextFocus = false;
  function metaById(id) {
    var all = loadMeta();
    for (var k = 0; k < all.length; k++) {
      if (all[k].id === id) return { all: all, m: all[k] };
    }
    return null;
  }
  document.body.addEventListener('mousedown', function (e) {
    if (e.button !== 0) return;
    var node = e.target && e.target.closest ? e.target.closest('.cloud-card, .cloud-text') : null;
    if (!node) return;
    var isText = node.classList.contains('cloud-text');
    // Текст таскается сразу, картинка — только с хинтом.
    if (!isText && !node.classList.contains('hint')) return;
    var f = metaById(node.dataset.id);
    if (!f) return;
    if (isText && !node.classList.contains('editing')) {
      // Фокус только по клику (mouseup без движения): иначе дергание при старте драга.
      pendingTextFocus = true;
    }
    if (!isText) e.preventDefault();
    var dd0 = dispSize({ w: f.m.w, h: f.m.h, dl: f.m.dl || f.m.dw });
    drag = {
      id: node.dataset.id, el: node,
      x0: e.clientX, y0: e.clientY,
      baseX: f.m.x, baseY: f.m.y,
      mw: f.m.w, mh: f.m.h,
      dl0: Math.max(dd0.w, dd0.h),
      rot0: f.m.rot || 0,
      isText: isText,
      moved: false, sized: false, sizeAcc: 0, z: node.style.zIndex,
      lastMove: performance.now(), oscOn: true
    };
    drag.dl = drag.dl0;
    // Качание угла: старт с текущего, период 3.5 секунды, на отпускании фиксируется.
    drag.phase0 = Math.asin(Math.min(1, Math.max(-1, drag.rot0 / 7)));
    drag.t0 = performance.now();
    requestAnimationFrame(tickOsc);
    try { top.__focusCardDrag = true; } catch (err) {}
    // Вьюпорт кэшируем на ведение: innerWidth/Height на каждый mousemove не читаем.
    drag.VW = window.innerWidth;
    drag.VH = window.innerHeight;
    window.addEventListener('wheel', onCardWheel, { passive: false });
    node.style.zIndex = '115';
    node.classList.add('drag');
    document.body.style.userSelect = 'none';
  });
  // Пока ведут — угол медленно качается -7..+7, на отпускании фиксируется.
  // Без движения дольше 3с цикл встает, рестарт — следующим mousemove.
  function tickOsc() {
    if (!drag) return;
    if (performance.now() - drag.lastMove > 3000) { drag.oscOn = false; return; }
    var t = (performance.now() - drag.t0) / 1000;
    var rot = Math.round(7 * Math.sin(drag.phase0 + t * (2 * Math.PI / 3.5)) * 10) / 10;
    rot = Math.min(7, Math.max(-7, rot));
    if (rot !== drag.rot) {
      drag.rot = rot;
      drag.sized = true;
      drag.el.style.setProperty('--rot', rot + 'deg');
    }
    requestAnimationFrame(tickOsc);
  }
  document.addEventListener('mousemove', function (e) {
    if (!drag) return;
    // Отпустили вне окна — кнопок уже нет, завершаем как mouseup.
    if (e.buttons === 0) { finishDrag(); return; }
    var dx = e.clientX - drag.x0, dy = e.clientY - drag.y0;
    if (!drag.moved && Math.abs(dx) + Math.abs(dy) < 4) return;
    drag.moved = true;
    pendingTextFocus = false;
    drag.lastMove = performance.now();
    if (!drag.oscOn) { drag.oscOn = true; requestAnimationFrame(tickOsc); }
    if (drag.isText) {
      // Поехали — правку сворачиваем, выделение чистим.
      if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
      if (window.getSelection) window.getSelection().removeAllRanges();
    }
    var nx = Math.min(0.98, Math.max(0.02, drag.baseX + dx / drag.VW));
    var ny = Math.min(0.98, Math.max(0.02, drag.baseY + dy / drag.VH));
    drag.el.style.left = (nx * 100) + '%';
    drag.el.style.top = (ny * 100) + '%';
    drag.nx = nx;
    drag.ny = ny;
  });
  // Единый финал drag: mouseup, уход кнопок, потеря фокуса.
  function finishDrag() {
    if (!drag) return;
    // Клик по тексту (без ведения) — вот тут и фокусимся для правки.
    if (pendingTextFocus && !drag.moved && drag.el.isConnected) {
      drag.el.classList.add('editing');
      drag.el.focus();
    }
    pendingTextFocus = false;
    if (drag.moved || drag.sized) {
      var f = metaById(drag.id);
      if (f) {
        if (drag.nx !== undefined) {
          f.m.x = Math.round(drag.nx * 10000) / 10000;
          f.m.y = Math.round(drag.ny * 10000) / 10000;
        }
        if (drag.dl !== undefined) f.m.dl = drag.dl;
        if (drag.rot !== undefined) f.m.rot = drag.rot;
        saveMeta(f.all);
      }
    }
    if (drag.moved) {
      dragEndTime = Date.now();
    }
    var restackId = drag.moved ? drag.id : null;
    drag.el.style.zIndex = drag.z;
    drag.el.classList.remove('drag');
    document.body.style.userSelect = '';
    window.removeEventListener('wheel', onCardWheel);
    try { top.__focusCardDrag = false; } catch (err) {}
    drag = null;
    // После восстановления визуала — только так нормализация видна сразу.
    if (restackId) normalizeZ(restackId);
  }
  document.addEventListener('mouseup', finishDrag);
  window.addEventListener('blur', finishDrag);
  // Колесо во время ведения: длинная сторона 200..320, вверх — больше.
  // Висит только пока ведут (иначе душит оптимизацию скролла фрейма).
  function onCardWheel(e) {
    if (!drag || drag.isText) return;
    e.preventDefault();
    drag.sizeAcc += -e.deltaY * 0.1;
    // Аккумулятор тоже в границах — иначе смена направления упирается в холостой ход.
    drag.sizeAcc = Math.min(320 - drag.dl0, Math.max(200 - drag.dl0, drag.sizeAcc));
    var dl = Math.round(drag.dl0 + drag.sizeAcc);
    if (dl !== drag.dl) {
      drag.dl = dl;
      drag.sized = true;
      drag.el.style.width = dispSize({ w: drag.mw, h: drag.mh, dl: dl }).w + 'px';
    }
  }
  // После перетаскивания ссылки клик не переходит — глушим его.
  document.body.addEventListener('click', function (e) {
    if (Date.now() - dragEndTime > 300) return;
    var card = e.target && e.target.closest ? e.target.closest('.cloud-card, .cloud-text') : null;
    if (card) { e.preventDefault(); e.stopPropagation(); }
  }, true);
  function renderAll() {
    var items = loadMeta();
    if (!items.length) return;
    // Синхронный каркас: тексты целиком + коробки картинок с геометрией из меты.
    // Иначе все ждут открытия IDB и влетают скопом уже после показа.
    items.forEach(function (m) {
      if (m.kind === 'text') {
        if (!document.querySelector('.cloud-text[data-id="' + m.id + '"]')) {
          document.body.appendChild(textEl(m));
        }
      } else if (!document.querySelector('.cloud-card[data-id="' + m.id + '"]')) {
        document.body.appendChild(cardShellEl(m));
      }
    });
    idb().then(function (db) {
      (function next(i) {
        if (i >= items.length) return;
        if (items[i].kind === 'text') { next(i + 1); return; }
        idbReq(db, 'readonly', function (st) { return st.get(items[i].id); }).then(function (blob) {
          if (blob) {
            var url = URL.createObjectURL(blob);
            objectUrls.push(url);
            var node = document.querySelector('.cloud-card[data-id="' + items[i].id + '"]');
            if (node && !node.querySelector('img.cloud-img')) {
              var im = document.createElement('img');
              im.className = 'cloud-img';
              im.addEventListener('load', function () { im.classList.add('ok'); }, { once: true });
              im.src = url;
              im.draggable = false;
              im.decoding = 'async';
              node.insertBefore(im, node.firstChild);
              // Старым карточкам без w/h прибиваем размер один раз и сохраняем.
              if (!items[i].w) {
                (function (m, n, nim) {
                  var pin = function () {
                    if (!nim.naturalWidth) return;
                    var all = loadMeta();
                    var f = null;
                    for (var k = 0; k < all.length; k++) {
                      if (all[k].id === m.id) { f = all[k]; break; }
                    }
                    if (f && !f.w) {
                      f.w = nim.naturalWidth; f.h = nim.naturalHeight;
                      f.dl = Math.round(280 + Math.random() * 40);
                      saveMeta(all);
                    }
                    n.style.width = dispSize(f || m).w + 'px';
                  };
                  if (nim.complete && nim.naturalWidth) pin();
                  else nim.addEventListener('load', pin, { once: true });
                })(items[i], node, im);
              }
            }
          }
          next(i + 1);
        }, function () { next(i + 1); });
      })(0);
    }, function (e) {
      console.warn('[cloud] idb unavailable:', e);
    });
  }
  // Каркас карточки без картинки: та же геометрия, блоб дольем позже.
  function cardShellEl(meta) {
    var el = document.createElement(meta.link ? 'a' : 'div');
    el.className = 'cloud-card';
    el.dataset.id = meta.id;
    if (meta.link) { el.href = meta.link; el.target = '_top'; }
    el.style.left = (meta.x * 100) + '%';
    el.style.top = (meta.y * 100) + '%';
    el.style.zIndex = String(meta.z);
    el.style.setProperty('--rot', meta.rot + 'deg');
    el.style.width = dispSize(meta).w + 'px';
    var hover = document.createElement('div');
    hover.className = 'card-hover';
    var hoverImg = document.createElement('img');
    hoverImg.src = 'icon/hoverImage.svg';
    hoverImg.alt = '';
    hoverImg.draggable = false;
    hover.appendChild(hoverImg);
    el.appendChild(hover);
    return el;
  }

  // Показываемый размер картинок: длинная сторона — свой рандом 280..320.
  // Тексту размер не считаем — у него max-width 300 и рост вниз.
  function dispSize(m) {
    if (m.kind === 'text') return { w: m.w || 220, h: m.h || 60 };
    var dl = m.dl || m.dw || SHOW_SIDE;
    var w = m.w || dl, h = m.h || dl;
    var s = dl / (Math.max(w, h) || dl);
    w = Math.max(1, Math.round(w * s));
    h = Math.max(1, Math.round(h * s));
    // Железно: ни одна сторона больше 320, пропорции сохраняем.
    if (w > 320 || h > 320) {
      var k = 320 / Math.max(w, h);
      w = Math.max(1, Math.round(w * k));
      h = Math.max(1, Math.round(h * k));
    }
    return { w: w, h: h };
  }
  // Стопка всегда компактная 10..10+n: перетащенная — наверх, остальные держат порядок.
  // Поэтому индексы не кончаются при любом числе перетаскиваний.
  function normalizeZ(topId) {
    var all = loadMeta();
    all.sort(function (a, b) {
      if (a.id === topId) return 1;
      if (b.id === topId) return -1;
      return a.z - b.z;
    });
    var byId = {};
    document.querySelectorAll('.cloud-card, .cloud-text').forEach(function (n) {
      if (n.dataset.id) byId[n.dataset.id] = n;
    });
    for (var i = 0; i < all.length; i++) {
      all[i].z = Z_BASE + i;
      if (byId[all[i].id]) byId[all[i].id].style.zIndex = String(all[i].z);
    }
    saveMeta(all);
  }
  // Свободное место при вставке: до 40 попыток не пересечься с лежащими.
  function findSpot(w, h, dl) {
    var d = dispSize({ w: w, h: h, dl: dl });
    return findSpotBox(d.w, d.h);
  }
  function findSpotBox(w, h) {
    var W = window.innerWidth, H = window.innerHeight, GAP = 12;
    var xMin = (w / 2 + 20) / W, xMax = 1 - (w / 2 + 20) / W;
    var yMin = (h / 2 + 20) / H, yMax = 1 - (h / 2 + 20) / H;
    if (xMax < xMin) { xMin = 0.08; xMax = 0.92; }
    if (yMax < yMin) { yMin = 0.1; yMax = 0.9; }
    var existing = loadMeta();
    for (var t = 0; t < 40; t++) {
      var x = xMin + Math.random() * Math.max(0.05, xMax - xMin);
      var y = yMin + Math.random() * Math.max(0.05, yMax - yMin);
      var ok = true;
      for (var k = 0; k < existing.length; k++) {
        var e = dispSize(existing[k]);
        if (Math.abs(x * W - existing[k].x * W) < (w + e.w) / 2 + GAP &&
            Math.abs(y * H - existing[k].y * H) < (h + e.h) / 2 + GAP) { ok = false; break; }
      }
      if (ok) return { x: x, y: y };
    }
    return { x: 0.1 + Math.random() * 0.8, y: 0.15 + Math.random() * 0.7 };
  }
  var confirmModal = null;
  function buildConfirm() {
    confirmModal = document.createElement('div');
    confirmModal.className = 'confirm-modal';
    confirmModal.hidden = true;
    confirmModal.innerHTML =
      '<div class="cf-block">' +
      '<img src="icon/lilac/eraserBig.svg" alt="" draggable="false">' +
      '<div class="cf-title">Очистить «Облачка» от картинок и надписей?</div>' +
      '<div class="cf-sub">Это не затронет другие пространства.</div>' +
      '</div>' +
      '<div class="pm-btns">' +
      '<button type="button" data-cc-clear>Очистить</button>' +
      '<button type="button" data-cc-keep>Оставить</button>' +
      '</div>';
    document.body.appendChild(confirmModal);
    confirmModal.querySelector('[data-cc-clear]').addEventListener('click', function () {
      hideConfirm();
      clearCloud().then(function () { toast('Облачка очищены'); }, function () { toast('Не вышло очистить'); });
    });
    confirmModal.querySelector('[data-cc-keep]').addEventListener('click', hideConfirm);
  }
  function showConfirm() {
    closeModal();
    hideCardMenu();
    hideTextMenu();
    scrim.hidden = false;
    confirmModal.hidden = false;
    chromeDim(true);
  }
  function hideConfirm() {
    if (confirmModal) confirmModal.hidden = true;
    if (modal && !modal.hidden) return;
    scrim.hidden = true;
    chromeDim(false);
  }
  /* ---- Очередь мутаций меты: читай-изменяй-пиши только по очереди,
     иначе быстрые вставки затирают друг друга. ---- */
  var opQueue = Promise.resolve(), cloudEpoch = 0;
  function enqueueOp(fn) {
    opQueue = opQueue.then(fn, fn);
    return opQueue;
  }
  // Зовет оболочка из ПКМ «Очистить всё».
  window.askClearCloud = function () { showConfirm(); };
  // Полная очистка.
  window.clearCloud = function () {
    cloudEpoch++;
    return enqueueOp(function () {
      return idb().then(function (db) {
        return idbReq(db, 'readwrite', function (st) { return st.clear(); });
      }).then(function () {
        // Мета одна на картинки и тексты — сносим всё разом.
        try { localStorage.removeItem(LS_KEY); } catch (e) {}
        try { localStorage.removeItem(DRAW_KEY); } catch (e) {}
        Object.keys(hintTimers).forEach(clearHintTimer);
        document.querySelectorAll('.cloud-card, .cloud-text').forEach(function (n) { n.remove(); });
        objectUrls.forEach(function (u) { try { URL.revokeObjectURL(u); } catch (e) {} });
        objectUrls = [];
        committed = [];
        session = [];
        renderDraw();
      });
    });
  };

  /* ---- Модалка вставки ---- */
  function buildModal() {
    scrim = document.createElement('div');
    scrim.className = 'paste-scrim';
    scrim.hidden = true;
    scrim.addEventListener('mousedown', function (e) {
      e.preventDefault();
      if (confirmModal && !confirmModal.hidden) hideConfirm();
      else closeModal();
    });
    document.body.appendChild(scrim);
    modal = document.createElement('div');
    modal.className = 'paste-modal';
    modal.hidden = true;
    modal.innerHTML =
      '<img data-pm-preview alt="">' +
      '<div class="pm-linkblock">' +
      '<div class="pm-text">Вы можете сделать картинку кликабельной добавив к ней ссылку.</div>' +
      '<input type="text" data-pm-link placeholder="например mail.ru" autocomplete="off" spellcheck="false">' +
      '</div>' +
      '<div class="pm-btns">' +
      '<button type="button" data-pm-cancel>Отмена</button>' +
      '<button type="button" data-pm-save>Добавить</button>' +
      '</div>';
    document.body.appendChild(modal);
    previewImg = modal.querySelector('[data-pm-preview]');
    linkInput = modal.querySelector('[data-pm-link]');
    linkInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') modalSave();
    });
    var saveBtn = modal.querySelector('[data-pm-save]');
    saveBtn.addEventListener('mousedown', function (e) { e.preventDefault(); });
    saveBtn.addEventListener('click', modalSave);
    modal.querySelector('[data-pm-cancel]').addEventListener('click', closeModal);
  }
  function discardPending() {
    if (pendingUrl) URL.revokeObjectURL(pendingUrl);
    pendingFile = null;
    pendingUrl = null;
  }
  function closeModal() {
    if (modal) modal.hidden = true;
    if (scrim) scrim.hidden = true;
    chromeDim(false);
    discardPending();
  }
  function openModal(file) {
    discardPending();
    hideConfirm();
    editingId = null; // режим создания
    pendingFile = file;
    previewImg.removeAttribute('src');
    previewImg.style.width = '';
    previewImg.style.height = '';
    linkInput.value = '';
    pendingUrl = URL.createObjectURL(file);
    // Размер превью узнаем до показа — модалка открывается сразу финальной, без прыжка.
    fileToBitmap(file).then(function (bmp) {
      try {
        if (file !== pendingFile || !bmp.width || !bmp.height) return;
        var s = Math.min(1, 250 / Math.max(bmp.width, bmp.height));
        previewImg.style.width = Math.max(1, Math.round(bmp.width * s)) + 'px';
        previewImg.style.height = Math.max(1, Math.round(bmp.height * s)) + 'px';
      } finally { if (bmp.close) bmp.close(); }
      previewImg.src = pendingUrl;
      showModalEls();
    }, function () {
      if (file !== pendingFile) return;
      previewImg.src = pendingUrl;
      showModalEls();
    });
  }
  function showModalEls() {
    scrim.hidden = false;
    modal.hidden = false;
    chromeDim(true);
    linkInput.focus();
  }
  function savePending() {
    if (!pendingFile) return;
    if (loadMeta().length >= MAX_ITEMS) { toast('Облачка полны — максимум 100'); closeModal(); return; }
    var file = pendingFile;
    var link = normalizeUrl(linkInput.value);
    closeModal();
    var e0 = cloudEpoch;
    processImage(file).then(function (r) {
      var blob = r.blob;
      var id = uid();
      return enqueueOp(function () {
        return idb().then(function (db) {
          return idbReq(db, 'readwrite', function (st) { return st.put(blob, id); }).then(function () {
            if (e0 !== cloudEpoch) {
              // Пока сохраняли — всё снесли: откатываем сироту из IDB.
              return idbReq(db, 'readwrite', function (st) { return st.delete(id); });
            }
            var items = loadMeta();
            var dl = Math.round(280 + Math.random() * 40);
            var spot = findSpot(r.w, r.h, dl);
            var meta = {
              id: id,
              x: spot.x,
              y: spot.y,
              rot: randomRot(),
              link: link,
              w: r.w,
              h: r.h,
              dl: dl,
              z: Z_BASE + (items.length % MAX_ITEMS)
            };
            saveMeta(items.concat([meta]));
            var url = URL.createObjectURL(blob);
            objectUrls.push(url);
            document.body.appendChild(cardEl(meta, url));
          });
        });
      });
    }, function (e) {
      console.warn('[cloud] save failed:', e);
      toast('Не вышло сохранить картинку');
    });
  }
  window.addEventListener('paste', function (e) {
    var items = (e.clipboardData && e.clipboardData.items) || [];
    var found = Array.prototype.slice.call(items).filter(function (it) {
      return it.type && it.type.indexOf('image/') === 0;
    })[0];
    if (!found) return; // текст — своим чередом
    if (!isSupportedImage(found.type)) {
      e.preventDefault();
      toast('Только PNG, JPEG и WebP');
      return;
    }
    var file = found.getAsFile();
    if (!file) return;
    e.preventDefault();
    if (modal && !modal.hidden) return;
    if (confirmModal && !confirmModal.hidden) return;
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    openModal(file);
  });

  /* ---- Меню картинки (ПКМ): общий компонент .menu, удалить / изменить ссылку ---- */
  var cardMenu = null, cardMenuTarget = null, editingId = null;
  function buildCardMenu() {
    cardMenu = document.createElement('div');
    cardMenu.className = 'menu card-menu';
    cardMenu.hidden = true;
    cardMenu.innerHTML =
      '<button type="button" class="mrow" data-cm-del>' +
      '<img src="icon/' + THEME + '/deleted.svg" alt="" draggable="false" data-errhide>' +
      '<span>Удалить картинку</span></button>' +
      '<div class="msep"></div>' +
      '<button type="button" class="mrow" data-cm-edit>' +
      '<img src="icon/' + THEME + '/link.svg" alt="" draggable="false" data-errhide>' +
      '<span>Изменить ссылку</span></button>';
    document.body.appendChild(cardMenu);
    cardMenu.querySelector('[data-cm-edit]').addEventListener('click', function () {
      var id = cardMenuTarget;
      hideCardMenu();
      openEditModal(id);
    });
    cardMenu.querySelector('[data-cm-del]').addEventListener('click', function () {
      var id = cardMenuTarget;
      hideCardMenu();
      deleteCard(id);
    });
  }
  function hideCardMenu() {
    if (!cardMenu) return;
    cardMenu.hidden = true;
    cardMenuTarget = null;
  }
  /* ---- Меню текста (ПКМ): удалить именно этот текст ---- */
  var textMenu = null, textMenuTarget = null;
  function buildTextMenu() {
    textMenu = document.createElement('div');
    textMenu.className = 'menu text-menu';
    textMenu.hidden = true;
    textMenu.innerHTML =
      '<button type="button" class="mrow" data-tm-del>' +
      '<img src="icon/' + THEME + '/deleted.svg" alt="" draggable="false" data-errhide>' +
      '<span>Удалить текст</span></button>';
    document.body.appendChild(textMenu);
    textMenu.querySelector('[data-tm-del]').addEventListener('click', function () {
      var id = textMenuTarget;
      hideTextMenu();
      deleteText(id);
    });
  }
  function hideTextMenu() {
    if (!textMenu) return;
    textMenu.hidden = true;
    textMenuTarget = null;
  }
  function openTextMenu(x, y, node) {
    closeModal();
    hideCardMenu();
    textMenuTarget = node.dataset.id;
    textMenu.style.left = Math.min(x, window.innerWidth - 200) + 'px';
    textMenu.style.top = Math.min(y, window.innerHeight - 150) + 'px';
    textMenu.hidden = false;
  }
  function openCardMenu(x, y, card) {
    closeModal();
    hideTextMenu();
    cardMenuTarget = card.dataset.id;
    cardMenu.style.left = Math.min(x, window.innerWidth - 200) + 'px';
    cardMenu.style.top = Math.min(y, window.innerHeight - 150) + 'px';
    cardMenu.hidden = false;
  }
  function deleteText(id) {
    clearHintTimer(id);
    var node = document.querySelector('.cloud-text[data-id="' + id + '"]');
    if (node) node.remove();
    var f = metaById(id);
    if (!f) return;
    saveMeta(f.all.filter(function (a) { return a.id !== id; }));
    toast('Текст удален');
  }
  // Правка ссылки — через общую модалку вставки с актуальными данными карточки.
  function openEditModal(id) {
    var f = metaById(id);
    if (!f) return;
    var node = document.querySelector('.cloud-card[data-id="' + id + '"]');
    var im = node && node.querySelector('img.cloud-img');
    discardPending();
    hideConfirm();
    editingId = id;
    previewImg.removeAttribute('src');
    previewImg.style.width = '';
    previewImg.style.height = '';
    if (f.m.w && f.m.h) {
      var es = Math.min(1, 250 / Math.max(f.m.w, f.m.h));
      previewImg.style.width = Math.max(1, Math.round(f.m.w * es)) + 'px';
      previewImg.style.height = Math.max(1, Math.round(f.m.h * es)) + 'px';
    }
    if (im) previewImg.src = im.src;
    linkInput.value = f.m.link || '';
    scrim.hidden = false;
    modal.hidden = false;
    chromeDim(true);
    linkInput.focus();
  }
  function modalSave() {
    if (editingId) saveEdit();
    else savePending();
  }
  function saveEdit() {
    var id = editingId;
    var link = normalizeUrl(linkInput.value);
    var f = metaById(id);
    editingId = null;
    closeModal();
    if (!f) return;
    f.m.link = link;
    saveMeta(f.all);
    var node = document.querySelector('.cloud-card[data-id="' + id + '"]');
    if (!node) return;
    if (link && node.tagName !== 'A') {
      var img = node.querySelector('img.cloud-img');
      var fresh = cardEl(f.m, img ? img.src : '');
      node.replaceWith(fresh);
    } else if (!link && node.tagName === 'A') {
      node.removeAttribute('href');
      node.removeAttribute('target');
    } else if (link) {
      node.href = link;
      node.target = '_top';
    }
  }
  function deleteCard(id) {
    clearHintTimer(id);
    var node = document.querySelector('.cloud-card[data-id="' + id + '"]');
    if (node) {
      var im = node.querySelector('img.cloud-img');
      if (im) {
        try { URL.revokeObjectURL(im.src); } catch (e) {}
        objectUrls = objectUrls.filter(function (u) { return u !== im.src; });
      }
      node.remove();
    }
    enqueueOp(function () {
      var f = metaById(id);
      if (!f) return Promise.resolve();
      return idb().then(function (db) {
        return idbReq(db, 'readwrite', function (st) { return st.delete(id); });
      }).then(function () {
        saveMeta(f.all.filter(function (a) { return a.id !== id; }));
        toast('Картинка удалена');
      }, function () { toast('Не вышло удалить'); });
    });
  }
  /* ---- Карандаш: один цвет (80%), сглаживание квадратиками + coalesced ---- */
  var DRAW_W = 3, DRAW_MIN_D = 0.0012, DRAW_SMOOTH = 0.45, DRAW_RDP_EPS = 0.002;
  var DRAW_KEY = 'focus:cloudDraw';
  var drawCanvas = null, drawBar = null;
  var drawMode = false, drawing = false, curStroke = null;
  var smX = 0, smY = 0;
  var committed = [], session = [];
  function buildDrawLayer() {
    drawCanvas = document.createElement('canvas');
    drawCanvas.className = 'draw-canvas';
    document.body.appendChild(drawCanvas);
    drawBar = document.createElement('div');
    drawBar.className = 'pm-btns draw-bar';
    drawBar.hidden = true;
    drawBar.innerHTML =
      '<button type="button" data-draw-cancel>Отменить</button>' +
      '<button type="button" data-draw-clear>Очистить рисованное</button>' +
      '<button type="button" data-draw-apply>Применить</button>';
    document.body.appendChild(drawBar);
    drawBar.querySelector('[data-draw-cancel]').addEventListener('click', function () { exitDraw(false); });
    drawBar.querySelector('[data-draw-clear]').addEventListener('click', function () { clearDraw(); });
    drawBar.querySelector('[data-draw-apply]').addEventListener('click', function () { exitDraw(true); });
    drawCanvas.addEventListener('pointerdown', onDrawDown);
    drawCanvas.addEventListener('pointermove', onDrawMove);
    drawCanvas.addEventListener('pointerup', onDrawUp);
    drawCanvas.addEventListener('pointercancel', onDrawUp);
    var drawRzT = 0;
    window.addEventListener('resize', function () {
      clearTimeout(drawRzT);
      drawRzT = setTimeout(function () { drawSetup(); renderDraw(); }, 150);
    });
    committed = loadDraw();
    drawSetup();
    renderDraw();
  }
  function loadDraw() {
    try {
      var a = JSON.parse(localStorage.getItem(DRAW_KEY));
      return Array.isArray(a) ? a : [];
    } catch (e) { return []; }
  }
  function persistDraw() {
    try {
      var clean = committed.map(function (st) {
        return st.map(function (p) {
          return [Math.round(p[0] * 10000) / 10000, Math.round(p[1] * 10000) / 10000];
        });
      });
      localStorage.setItem(DRAW_KEY, JSON.stringify(clean));
    } catch (e) {}
  }
  var drawColorCache = null;
  function drawColor() {
    if (drawColorCache) return drawColorCache;
    try {
      var v = getComputedStyle(document.documentElement).getPropertyValue('--c-80');
      if (v && v.trim()) { drawColorCache = v.trim(); return drawColorCache; }
    } catch (e) {}
    return '#7A6EF7';
  }
  function drawSetup() {
    var dpr = window.devicePixelRatio || 1;
    var W = window.innerWidth, H = window.innerHeight;
    drawCanvas.width = Math.max(1, Math.round(W * dpr));
    drawCanvas.height = Math.max(1, Math.round(H * dpr));
    drawCanvas.style.width = W + 'px';
    drawCanvas.style.height = H + 'px';
    var ctx = drawCanvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
  }
  // Кэтмулл-Ром в Безье: гладко через все точки при любом шаге, граней нет.
  function strokePath(ctx, pts, W, H) {
    var n = pts.length;
    if (!n) return;
    function X(i) { return pts[Math.min(Math.max(i, 0), n - 1)][0] * W; }
    function Y(i) { return pts[Math.min(Math.max(i, 0), n - 1)][1] * H; }
    ctx.beginPath();
    if (n === 1) {
      ctx.arc(X(0), Y(0), DRAW_W / 2, 0, Math.PI * 2);
      ctx.fill();
      return;
    }
    if (n === 2) {
      ctx.moveTo(X(0), Y(0));
      ctx.lineTo(X(1), Y(1));
      ctx.stroke();
      return;
    }
    ctx.moveTo(X(0), Y(0));
    for (var i = 0; i < n - 1; i++) {
      var p0x = X(i - 1), p0y = Y(i - 1);
      var p1x = X(i), p1y = Y(i);
      var p2x = X(i + 1), p2y = Y(i + 1);
      var p3x = X(i + 2), p3y = Y(i + 2);
      ctx.bezierCurveTo(
        p1x + (p2x - p0x) / 6, p1y + (p2y - p0y) / 6,
        p2x - (p3x - p1x) / 6, p2y - (p3y - p1y) / 6,
        p2x, p2y
      );
    }
    ctx.stroke();
  }
  // Перерисовка не чаще кадра: pointermove шлет чаще, чем экран.
  var drawQueued = false;
  function queueRenderDraw() {
    if (drawQueued) return;
    drawQueued = true;
    requestAnimationFrame(function () { drawQueued = false; renderDraw(); });
  }
  function renderDraw() {
    if (!drawCanvas) return;
    var ctx = drawCanvas.getContext('2d');
    var W = window.innerWidth, H = window.innerHeight;
    ctx.clearRect(0, 0, W, H);
    var all = committed.concat(session);
    if (!all.length) return;
    ctx.strokeStyle = drawColor();
    ctx.fillStyle = drawColor();
    ctx.lineWidth = DRAW_W;
    for (var i = 0; i < all.length; i++) strokePath(ctx, all[i], W, H);
  }
  function onDrawDown(e) {
    if (e.button !== 0 || !drawMode) return;
    e.preventDefault();
    // Бэкинг под текущий DPR на каждый штрих — зум после создания не мылит.
    drawSetup();
    var W = window.innerWidth, H = window.innerHeight;
    drawing = true;
    curStroke = [[e.clientX / W, e.clientY / H]];
    session.push(curStroke);
    smX = e.clientX / W;
    smY = e.clientY / H;
    try { drawCanvas.setPointerCapture(e.pointerId); } catch (err) {}
    renderDraw();
  }
  function onDrawMove(e) {
    if (!drawing || !curStroke) return;
    e.preventDefault();
    var W = window.innerWidth, H = window.innerHeight;
    var evs = (e.getCoalescedEvents && e.getCoalescedEvents()) || [e];
    var added = false;
    for (var i = 0; i < evs.length; i++) {
      // Экспоненциальное сглаживание входа — убирает тремор, намерение держит.
      smX += DRAW_SMOOTH * (evs[i].clientX / W - smX);
      smY += DRAW_SMOOTH * (evs[i].clientY / H - smY);
      var nx = smX, ny = smY;
      var last = curStroke[curStroke.length - 1];
      var dx = nx - last[0], dy = ny - last[1];
      if (dx * dx + dy * dy < DRAW_MIN_D * DRAW_MIN_D) continue;
      curStroke.push([nx, ny]);
      added = true;
    }
    if (added) queueRenderDraw();
  }
  // Рамер-Дуглас-Пекер: выкидывает шумовые точки, сплайн ложится чище.
  function rdp(points, eps) {
    if (points.length < 3) return points.slice();
    var keep = [];
    for (var k = 0; k < points.length; k++) keep.push(false);
    keep[0] = keep[points.length - 1] = true;
    var stack = [[0, points.length - 1]];
    while (stack.length) {
      var seg = stack.pop();
      var a = seg[0], b = seg[1];
      var ax = points[a][0], ay = points[a][1];
      var dx = points[b][0] - ax, dy = points[b][1] - ay;
      var len2 = dx * dx + dy * dy;
      var maxD = 0, idx = -1;
      for (var i = a + 1; i < b; i++) {
        var d;
        if (!len2) {
          var ex = points[i][0] - ax, ey = points[i][1] - ay;
          d = Math.sqrt(ex * ex + ey * ey);
        } else {
          var t = ((points[i][0] - ax) * dx + (points[i][1] - ay) * dy) / len2;
          t = t < 0 ? 0 : (t > 1 ? 1 : t);
          var px = ax + t * dx - points[i][0], py = ay + t * dy - points[i][1];
          d = Math.sqrt(px * px + py * py);
        }
        if (d > maxD) { maxD = d; idx = i; }
      }
      if (maxD > eps) { keep[idx] = true; stack.push([a, idx]); stack.push([idx, b]); }
    }
    var out = [];
    for (var j = 0; j < points.length; j++) {
      if (keep[j]) out.push(points[j]);
    }
    return out;
  }
  function onDrawUp() {
    drawing = false;
    if (curStroke && curStroke.length > 2) {
      var simple = rdp(curStroke, DRAW_RDP_EPS);
      if (simple.length >= 2) {
        curStroke.length = 0;
        for (var i = 0; i < simple.length; i++) curStroke.push(simple[i]);
      }
      renderDraw();
    }
    curStroke = null;
  }
  window.startDraw = function () {
    closeModal();
    hideCardMenu();
    hideTextMenu();
    hideConfirm();
    committed = loadDraw();
    session = [];
    drawSetup();
    renderDraw();
    drawMode = true;
    drawCanvas.classList.add('on');
    drawBar.hidden = false;
    setBusy(true);
  };
  // Стереть всё нарисованное (остаемся в режиме).
  function clearDraw() {
    committed = [];
    session = [];
    drawing = false;
    curStroke = null;
    persistDraw();
    renderDraw();
  }
  function exitDraw(save) {    if (save && session.length) {
      committed = committed.concat(session);
      persistDraw();
    }
    session = [];
    drawing = false;
    curStroke = null;
    drawMode = false;
    if (drawCanvas) drawCanvas.classList.remove('on');
    if (drawBar) drawBar.hidden = true;
    setBusy(false);
    renderDraw();
  }
  function setBusy(on) {
    try { top.__cloudBusy = !!on; } catch (e) {}
  }

  /* ---- Дроп файлов: индикатор + прием первой картинки в ту же модалку ---- */
  var dropOverlay = null;
  function buildDropOverlay() {
    dropOverlay = document.createElement('div');
    dropOverlay.className = 'drop-overlay';
    dropOverlay.hidden = true;
    var im = document.createElement('img');
    im.src = 'icon/drop.svg';
    im.alt = '';
    im.draggable = false;
    dropOverlay.appendChild(im);
    document.body.appendChild(dropOverlay);
  }
  function hasFiles(e) {
    var t = e.dataTransfer && e.dataTransfer.types;
    return !!t && Array.prototype.indexOf.call(t, 'Files') !== -1;
  }
  // Счетчик входов: relatedTarget у dragleave ненадежен, оверлей бы залипал.
  var dragDepth = 0;
  window.addEventListener('dragenter', function (e) {
    if (!hasFiles(e)) return;
    e.preventDefault();
    dragDepth++;
    dropOverlay.hidden = false;
  });
  window.addEventListener('dragover', function (e) {
    if (!hasFiles(e)) return;
    e.preventDefault();
    dropOverlay.hidden = false;
  });
  window.addEventListener('dragleave', function (e) {
    if (!hasFiles(e)) return;
    if (--dragDepth <= 0) { dragDepth = 0; dropOverlay.hidden = true; }
  });
  window.addEventListener('drop', function (e) {
    if (!hasFiles(e)) return;
    e.preventDefault();
    dragDepth = 0;
    dropOverlay.hidden = true;
    if (modal && !modal.hidden) return;
    if (confirmModal && !confirmModal.hidden) return;
    var fs = e.dataTransfer.files || [];
    var img = null, hadImage = false;
    for (var i = 0; i < fs.length; i++) {
      var ft = fs[i].type || '';
      if (ft.indexOf('image/') !== 0) continue;
      hadImage = true;
      if (isSupportedImage(ft)) { img = fs[i]; break; }
    }
    if (!img) { toast(hadImage ? 'Только PNG, JPEG и WebP' : 'Сюда можно только картинки'); return; }
    openModal(img);
  });

  buildModal();
  buildCardMenu();
  buildTextMenu();
  buildConfirm();
  buildDropOverlay();
  buildDrawLayer();
  renderAll();
  // Статика (сетка+поиск) готова — оболочка показывает фрейм и снимает слепок.
  // Картинки из IDB догоняют сами, поиск и сетка при этом стоят монолитом.
  try {
    requestAnimationFrame(function () {
      try { window.top.__cloudReady(); } catch (e) {}
    });
  } catch (e) {}
})();


// data-errhide imgs hide on error (CSP-safe, no inline handlers).
document.addEventListener('error', function (e) {
  var t = e.target;
  if (t && t.tagName === 'IMG' && t.hasAttribute && t.hasAttribute('data-errhide')) { t.style.display = 'none'; }
}, true);