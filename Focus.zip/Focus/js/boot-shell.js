
// Оболочка знает только: где был юзер и какая тема. Все до paint.
(function () {
  try {
    var s = localStorage.getItem('focus:lastSpace');
    if (s === 'center') s = 'focus'; // миграция со старых имен
    else if (s === 'plus') s = 'focusplus';
    if (s !== 'cloud' && s !== 'focusplus') s = 'focus';
    var t = localStorage.getItem('focus:theme');
    if (t !== 'lilac') t = 'lilac'; // пока одна палитра
    document.documentElement.dataset.space = s;
    document.documentElement.dataset.theme = t;
    window.__FOCUS_INITIAL_SPACE = s;
  } catch (e) {
    document.documentElement.dataset.space = 'focus';
    window.__FOCUS_INITIAL_SPACE = 'focus';
  }
})();
