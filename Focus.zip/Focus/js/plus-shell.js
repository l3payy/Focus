(function () {
  'use strict';
  // Фокус+ живет в оболочке: один документ, один paint. Чужих слотов не знаем.
  var PLUS_SLOT = '[data-space="focusplus"]';
  function toast(m) {
    try { if (typeof window.__focusToast === 'function') window.__focusToast(m); } catch (e) {}
  }
  function spaceActive() {
    try { return (document.documentElement.dataset.space || 'focus') === 'focusplus'; }
    catch (e) { return false; }
  }
  var TILE = 68;

  /* ---- Тема и провайдер (свой ключ, фолбэк общий) ---- */
  var THEME = 'lilac';
  try { THEME = localStorage.getItem('focus:theme') || 'lilac'; } catch (e) {}
  function searchProvider() {
    try {
      return localStorage.getItem('focus:search:focusplus')
        || localStorage.getItem('focus:search')
        || 'google';
    } catch (e) { return 'google'; }
  }
  var PROVIDER_ICON = { yandex: 'icon/yandex.svg', google: 'icon/google.svg' };
  function refreshProviderIcon() {
    document.querySelectorAll(PLUS_SLOT + ' [data-provider-icon]').forEach(function (img) {
      img.src = PROVIDER_ICON[searchProvider()] || PROVIDER_ICON.google;
    });
  }
  function searchOn() {
    try { return localStorage.getItem('focus:searchVis:focusplus') !== '0'; }
    catch (e) { return true; }
  }
  function applySearchVis() {
    var b = document.querySelector(PLUS_SLOT + ' [data-search-box]');
    if (b) b.style.display = searchOn() ? '' : 'none';
  }
  applySearchVis();
  window.addEventListener('storage', function (e) {
    if (e.key === 'focus:theme') {
      try { document.documentElement.dataset.theme = localStorage.getItem('focus:theme') || 'lilac'; } catch (err) {}
    }
    if (e.key === 'focus:search' || e.key === 'focus:search:focusplus') refreshProviderIcon();
    if (e.key === 'focus:searchVis:focusplus') applySearchVis();
    if (e.key === 'focus:bg:focusplus') applyBg();
    // Чужая вкладка поменяла сетку — перерисовать, иначе last-write-wins.
    if (e.key === SITES_KEY) renderGrid();
  });

  /* ---- Поиск ---- */
  var box = document.querySelector(PLUS_SLOT + ' [data-search-box]');
  var input = document.querySelector(PLUS_SLOT + ' [data-search]');
  var goBtn = document.querySelector(PLUS_SLOT + ' [data-search-go]');
  if (box && input && goBtn) {
    (function initSearch() {
      function doSearch() {
        if (!input.value.trim()) return;
        var q = encodeURIComponent(input.value.trim());
        location.href = searchProvider() === 'yandex'
          ? 'https://ya.ru/search/?text=' + q
          : 'https://www.google.com/search?q=' + q;
      }
      box.addEventListener('mousedown', function (e) {
        if (e.target === input || e.target === goBtn) return;
        e.preventDefault();
        input.focus();
      });
      input.addEventListener('focus', function () { box.classList.add('open'); });
      input.addEventListener('blur', function () {
        if (!input.value.trim()) box.classList.remove('open');
      });
      input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') doSearch();
        if (e.key === 'Escape') { input.value = ''; input.blur(); }
      });
      goBtn.addEventListener('mousedown', function (e) { e.preventDefault(); });
      goBtn.addEventListener('click', doSearch);
    })();
  }

  /* ---- Клавиатура и ПКМ. Навигацию делает оболочка, здесь только Escape. ---- */
  window.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && linkModal && !linkModal.hidden) { closeLinkModal(); return; }
    if (e.key === 'Escape' && cellMenu && !cellMenu.hidden) { hideCellMenu(); return; }
  });
  window.addEventListener('mousedown', function (e) {
    // В одном документе с меню оболочки: клик по меню/окнам не гасим.
    try {
      if (e.target && e.target.closest && e.target.closest('.ctx-menu, .settings-win, .link-modal, .site-menu, .cell-menu')) return;
      if (typeof window.closeCtx === 'function') window.closeCtx();
    } catch (err) {}
  });
  window.addEventListener('mousedown', function (e) {
    if (cellMenu && !cellMenu.hidden && !cellMenu.contains(e.target)) hideCellMenu();
  });
  window.addEventListener('contextmenu', function (e) {
    if (!e.target.closest || !e.target.closest(PLUS_SLOT)) return; // чужое — дело оболочки
    var cell = e.target.closest('.cell');
    if (cell) {
      e.preventDefault();
      openCellMenu(e.clientX, e.clientY, cell);
      return;
    }
    if (e.target.closest('img, canvas, input, textarea, a, button, .search, .link-modal')) return;
    e.preventDefault();
    hideCellMenu();
    try { if (typeof window.openCtx === 'function') window.openCtx(e.clientX, e.clientY); } catch (err) {}
  });

  /* ---- Сетка: слева направо, максимум 72 ---- */
  var SITES_KEY = 'focus:sitesPlus';
  var SITES_MAX = 72;
  function loadSites() {
    try {
      var a = JSON.parse(localStorage.getItem(SITES_KEY));
      if (Array.isArray(a)) {
        return a.filter(function (s) {
          return s && typeof s.id === 'string' && typeof s.url === 'string' && normalizeUrl(s.url);
        });
      }
    } catch (e) {}
    try { localStorage.setItem(SITES_KEY, JSON.stringify([])); } catch (err) {}
    return [];
  }
  function saveSites(items) {
    try { localStorage.setItem(SITES_KEY, JSON.stringify(items)); return true; }
    catch (e) { toast('Хранилище переполнено — не сохранено'); return false; }
  }
  function siteById(id) {
    var all = loadSites();
    for (var k = 0; k < all.length; k++) {
      if (all[k].id === id) return { all: all, m: all[k] };
    }
    return null;
  }
  function hostOf(url) {
    try { return new URL(url).hostname.replace(/^www\./, ''); }
    catch (e) { return ''; }
  }
  function siteStyle(host) {
    var h = (host || '').toLowerCase();
    while (h) {
      if (window.SITES_DB && window.SITES_DB[h]) return window.SITES_DB[h];
      var dot = h.indexOf('.');
      if (dot < 0) break;
      h = h.slice(dot + 1);
    }
    return {};
  }
  // Имя: словарь -> красивый домен (youtube.com -> Youtube).
  function prettyName(url, name) {
    var h = hostOf(url);
    var st = siteStyle(h);
    if (name) return name;
    if (st.name) return st.name;
    var first = (h.split('.')[0] || 'Сайт');
    return first.charAt(0).toUpperCase() + first.slice(1);
  }
  function faviconUrl(url) {
    var h = hostOf(url);
    if (!h) return '';
    return 'https://www.google.com/s2/favicons?domain=' + encodeURIComponent(h) + '&sz=128';
  }
  function normalizeUrl(v) {
    v = (v || '').trim();
    if (!v) return '';
    if (!/^[a-z]+:\/\//i.test(v)) v = 'https://' + v;
    if (/[\s<>]/.test(v)) return '';
    return /^https?:\/\/[^\/\s]+/.test(v) ? v : '';
  }
  function uid() {
    return 'plus_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 9);
  }
  function iconPx(st) {
    // Размер из базы под плитку 68 (база калибрована под 52).
    if (!st.icon) return TILE;
    return Math.round(st.icon * TILE / 52);
  }
  function cellEl(site) {
    // URL ревалидируем: старые записи могли сохранить javascript:.
    var cleanUrl = normalizeUrl(site.url);
    if (!cleanUrl) return document.createComment('bad site');
    var a = document.createElement('a');
    a.className = 'cell';
    a.dataset.id = site.id;
    a.href = cleanUrl;
    a.target = '_top';
    var host = hostOf(site.url);
    var st = siteStyle(host);
    var icon = document.createElement('span');
    icon.className = 'cell-icon';
    if (st.bg) icon.style.background = st.bg;
    var letter = document.createElement('span');
    letter.className = 'cell-letter';
    letter.textContent = ((host.charAt(0) || '?')).toUpperCase();
    icon.appendChild(letter);
    var src = faviconUrl(site.url);
    if (src && navigator.onLine !== false) {
      var img = document.createElement('img');
      img.src = src;
      img.alt = '';
      img.draggable = false;
      img.loading = 'lazy';
      img.referrerPolicy = 'no-referrer';
      img.style.left = '50%';
      img.style.top = '50%';
      img.style.right = 'auto';
      img.style.bottom = 'auto';
      img.style.transform = 'translate(-50%, -50%)';
      // Размер из базы; fit:'long' — длинная сторона после загрузки.
      var applyIconSize = function () {
        var px = iconPx(st);
        if (st.fit === 'long' && img.naturalWidth && img.naturalHeight) {
          if (img.naturalWidth >= img.naturalHeight) {
            img.style.width = px + 'px';
            img.style.height = 'auto';
          } else {
            img.style.height = px + 'px';
            img.style.width = 'auto';
          }
        } else {
          img.style.width = px + 'px';
          img.style.height = 'auto';
        }
      };
      if (img.complete && img.naturalWidth) applyIconSize();
      else img.addEventListener('load', applyIconSize, { once: true });
      // Буква показывается только если фавикон не загрузился.
      // s2 для мусора отдает 200 с глобусом — тогда пробуем origin/favicon.ico.
      var done = false;
      var fbTimer = setTimeout(function () {
        if (!done && img.isConnected) { done = true; img.remove(); letter.style.display = 'flex'; }
      }, 8000);
      img.dataset.tryOrigin = '1';
      img.addEventListener('load', function () { done = true; clearTimeout(fbTimer); img.classList.add('ok'); }, { once: true });
      img.addEventListener('error', function h() {
        if (img.dataset.tryOrigin) {
          delete img.dataset.tryOrigin;
          try {
            var origin = new URL(site.url).origin;
            img.src = origin + '/favicon.ico';
            return;
          } catch (e) {}
        }
        done = true;
        clearTimeout(fbTimer);
        img.remove();
        letter.style.display = 'flex';
      });
      img.dataset.tryOrigin = '1';
      icon.appendChild(img);
    } else {
      letter.style.display = 'flex';
    }
    a.appendChild(icon);
    var name = document.createElement('span');
    name.className = 'cell-name';
    name.textContent = (site.name || prettyName(site.url)).slice(0, 40);
    a.appendChild(name);
    return a;
  }
  function gridEl() {
    return document.querySelector(PLUS_SLOT + ' [data-grid]');
  }
  function renderGrid() {
    var grid = gridEl();
    if (!grid) return;
    var items = loadSites();
    // Гидрация: синхронная покраска уже стоит — не сносим, иначе блинк.
    if (grid.children.length) {
      var wantIds = items.map(function (s) { return s.id; }).join('|');
      var haveIds = Array.prototype.map.call(
        grid.querySelectorAll('.cell[data-id]'), function (n) { return n.getAttribute('data-id'); }
      ).join('|');
      if (wantIds === haveIds) {
        items.forEach(function (s) {
          var node = grid.querySelector('.cell[data-id="' + s.id + '"]');
          if (node && !node.querySelector('img')) {
            var fresh = cellEl(s);
            if (fresh.nodeType === 1) node.replaceWith(fresh);
          }
        });
        return;
      }
    }
    grid.innerHTML = '';
    items.forEach(function (s) { grid.appendChild(cellEl(s)); });
  }

  /* ---- Фон: картинка cover + вуаль Beck строго на слоте Плюса ---- */
  var bgUrl = null, bgReady = false, lqipEl = null;
  function plusSlotEl() {
    return document.querySelector(PLUS_SLOT);
  }
  function showLqip(thumb) {
    var slot = plusSlotEl();
    if (!slot) return;
    if (lqipEl && lqipEl.isConnected) return;
    var sync = slot.querySelector('.lqip');
    if (sync) { lqipEl = sync; return; }
    lqipEl = document.createElement('div');
    lqipEl.className = 'lqip';
    lqipEl.style.backgroundImage = 'url("' + thumb + '")';
    slot.appendChild(lqipEl);
  }
  function hideLqip() {
    if (lqipEl && lqipEl.isConnected) {
      var el = lqipEl;
      lqipEl = null;
      el.style.opacity = '0';
      setTimeout(function () { el.remove(); }, 250);
      return;
    }
    lqipEl = null;
    var slot = plusSlotEl();
    if (!slot) return;
    var sync = slot.querySelector('.lqip');
    if (sync) {
      sync.style.opacity = '0';
      setTimeout(function () { sync.remove(); }, 250);
    }
  }
  function makeThumb(blob) {
    return new Promise(function (resolve) {
      var url = URL.createObjectURL(blob);
      var im = new Image();
      im.onload = function () {
        try {
          var s = 32 / Math.max(im.naturalWidth, im.naturalHeight);
          var c = document.createElement('canvas');
          c.width = Math.max(1, Math.round(im.naturalWidth * s));
          c.height = Math.max(1, Math.round(im.naturalHeight * s));
          c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
          resolve(c.toDataURL('image/jpeg', 0.6));
        } catch (e) { resolve(''); }
        URL.revokeObjectURL(url);
      };
      im.onerror = function () { URL.revokeObjectURL(url); resolve(''); };
      im.src = url;
    });
  }
  function bgMeta() {
    try { return JSON.parse(localStorage.getItem('focus:bg:focusplus')) || null; }
    catch (e) { return null; }
  }
  var bgDbPromise = null;
  function idbBg() {
    if (!bgDbPromise) {
      bgDbPromise = new Promise(function (resolve, reject) {
        var req = indexedDB.open('focus-db', 2);
        req.onupgradeneeded = function () {
          if (!req.result.objectStoreNames.contains('images')) req.result.createObjectStore('images');
          if (!req.result.objectStoreNames.contains('backgrounds')) req.result.createObjectStore('backgrounds');
        };
        req.onsuccess = function () {
          var db = req.result;
          db.onversionchange = function () { db.close(); bgDbPromise = null; };
          resolve(db);
        };
        req.onerror = function () { bgDbPromise = null; reject(req.error); };
        req.onblocked = function () { bgDbPromise = null; reject(new Error('idb blocked')); };
      });
    }
    return bgDbPromise;
  }
  function clearBg() {
    bgReady = false;
    hideLqip();
    var slot = plusSlotEl();
    if (!slot) return;
    slot.style.backgroundImage = '';
    slot.style.removeProperty('--shadow-color');
    slot.style.removeProperty('--cell-text');
    if (bgUrl) { try { URL.revokeObjectURL(bgUrl); } catch (e) {} bgUrl = null; }
  }
  function applyBg() {
    var slot = plusSlotEl();
    var meta = bgMeta();
    if (!meta || !slot) { clearBg(); return; }
    // Первый кадр сразу из синхронной заглушки — моргания нет.
    if (meta.thumb && !bgReady) showLqip(meta.thumb);
    var pct = typeof meta.dim === 'number' ? meta.dim : 50;
    idbBg().then(function (db) {
      return new Promise(function (resolve, reject) {
        var rq = db.transaction('backgrounds', 'readonly').objectStore('backgrounds').get('focusplus');
        rq.onsuccess = function () { resolve(rq.result); };
        rq.onerror = function () { reject(rq.error); };
      });
    }).then(function (blob) {
      if (!blob) { clearBg(); return; }
      if (bgUrl) { try { URL.revokeObjectURL(bgUrl); } catch (e) {} }
      bgUrl = URL.createObjectURL(blob);
      var mix = 'color-mix(in srgb, var(--c-beck) ' + pct + '%, transparent)';
      slot.style.backgroundImage = 'linear-gradient(' + mix + ', ' + mix + '), url("' + bgUrl + '")';
      slot.style.backgroundSize = 'auto, cover';
      slot.style.backgroundPosition = 'center, center';
      slot.style.backgroundRepeat = 'no-repeat';
      if (pct === 0) {
        slot.style.setProperty('--shadow-color', 'rgba(0, 0, 0, 0.5)');
        slot.style.setProperty('--cell-text', 'rgba(255, 255, 255, 0.6)');
      } else {
        slot.style.removeProperty('--shadow-color');
        slot.style.removeProperty('--cell-text');
      }
      bgReady = true;
      hideLqip();
      // Миграция: у старых фонов заглушки нет — сделать один раз.
      if (!meta.thumb) {
        makeThumb(blob).then(function (t) {
          if (!t) return;
          var m = bgMeta() || {};
          if (m.thumb) return;
          m.thumb = t;
          try { localStorage.setItem('focus:bg:focusplus', JSON.stringify(m)); } catch (e) {}
        });
      }
    }, clearBg);
  }

  /* ---- Модалка ссылки + имя ---- */
  var linkModal = null, linkScrim = null, linkInput = null, nameInput = null, linkTitle = null, editingSiteId = null;
  function buildLinkModal() {
    linkScrim = document.createElement('div');
    linkScrim.className = 'link-scrim';
    linkScrim.hidden = true;
    linkScrim.addEventListener('mousedown', function (e) { e.preventDefault(); closeLinkModal(); });
    document.body.appendChild(linkScrim);
    linkModal = document.createElement('div');
    linkModal.className = 'link-modal';
    linkModal.hidden = true;
    linkModal.innerHTML =
      '<div class="lm-title" data-lm-title>Добавьте ссылку на сайт</div>' +
      '<input type="text" class="lm-input" data-lm-name placeholder="Название" autocomplete="off" spellcheck="false">' +
      '<input type="text" class="lm-input" data-lm-input placeholder="например youtube.com" autocomplete="off" spellcheck="false">' +
      '<div class="lm-btns">' +
      '<button type="button" data-lm-cancel>Отмена</button>' +
      '<button type="button" data-lm-save>Добавить</button>' +
      '</div>';
    document.body.appendChild(linkModal);
    linkTitle = linkModal.querySelector('[data-lm-title]');
    nameInput = linkModal.querySelector('[data-lm-name]');
    linkInput = linkModal.querySelector('[data-lm-input]');
    linkInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') saveLinkModal();
    });
    nameInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') saveLinkModal();
    });
    var saveBtn = linkModal.querySelector('[data-lm-save]');
    saveBtn.addEventListener('mousedown', function (e) { e.preventDefault(); });
    saveBtn.addEventListener('click', saveLinkModal);
    linkModal.querySelector('[data-lm-cancel]').addEventListener('click', closeLinkModal);
  }
  function openLinkModal(site, presetUrl) {
    hideCellMenu();
    editingSiteId = site ? site.id : null;
    linkTitle.textContent = site ? 'Изменить ссылку на сайт' : 'Добавьте ссылку на сайт';
    linkInput.value = site ? site.url : (presetUrl || '');
    nameInput.value = site ? (site.name || '') : (presetUrl ? prettyName(presetUrl) : '');
    linkScrim.hidden = false;
    linkModal.hidden = false;
    (site ? nameInput : linkInput).focus();
  }
  function closeLinkModal() {
    if (linkModal) linkModal.hidden = true;
    if (linkScrim) linkScrim.hidden = true;
    editingSiteId = null;
  }
  function saveLinkModal() {
    var rawLink = linkInput.value || '';
    if (rawLink.length > 2048) { toast('Слишком длинная ссылка'); return; }
    var u = normalizeUrl(rawLink);
    if (!u) { toast('Вставь ссылку, например youtube.com'); return; }
    var nm = (nameInput.value || '').trim().slice(0, 40) || prettyName(u);
    var items = loadSites();
    if (editingSiteId) {
      var f = siteById(editingSiteId);
      if (!f) { closeLinkModal(); return; }
      if (f.all.some(function (s) { return s.id !== editingSiteId && s.url === u; })) {
        toast('Уже добавлено');
        return;
      }
      f.m.url = u;
      f.m.name = nm;
      if (!saveSites(f.all)) return;
      closeLinkModal();
      var old = document.querySelector(PLUS_SLOT + ' .cell[data-id="' + editingSiteId + '"]');
      var fresh = cellEl(f.m);
      if (old && fresh.nodeType === 1) old.replaceWith(fresh);
      else renderGrid();
    } else {
      if (items.length >= SITES_MAX) { toast('Сетка полна — максимум 72'); return; }
      if (items.some(function (s) { return s.url === u; })) { toast('Уже добавлено'); return; }
      var meta = { id: uid(), url: u, name: nm };
      items.push(meta);
      if (!saveSites(items)) return;
      closeLinkModal();
      var grid = gridEl();
      if (grid) grid.appendChild(cellEl(meta));
      else renderGrid();
    }
  }
  window.addPlusSite = function () { openLinkModal(null); };

  /* ---- Меню ячейки (ПКМ): удалить / изменить ---- */
  var cellMenu = null, cellMenuTarget = null;
  function buildCellMenu() {
    cellMenu = document.createElement('div');
    cellMenu.className = 'menu cell-menu';
    cellMenu.hidden = true;
    cellMenu.innerHTML =
      '<button type="button" class="mrow" data-cm-del>' +
      '<img src="icon/' + THEME + '/deleted.svg" alt="" draggable="false" data-errhide>' +
      '<span>Удалить сайт</span></button>' +
      '<div class="msep"></div>' +
      '<button type="button" class="mrow" data-cm-edit>' +
      '<img src="icon/' + THEME + '/link.svg" alt="" draggable="false" data-errhide>' +
      '<span>Изменить ссылку</span></button>';
    document.body.appendChild(cellMenu);
    cellMenu.querySelector('[data-cm-del]').addEventListener('click', function () {
      var id = cellMenuTarget;
      hideCellMenu();
      var f = siteById(id);
      if (!f) return;
      saveSites(f.all.filter(function (a) { return a.id !== id; }));
      var node = document.querySelector(PLUS_SLOT + ' .cell[data-id="' + id + '"]');
      if (node) node.remove();
    });
    cellMenu.querySelector('[data-cm-edit]').addEventListener('click', function () {
      var f = siteById(cellMenuTarget);
      hideCellMenu();
      if (f) openLinkModal(f.m);
    });
  }
  function hideCellMenu() {
    if (!cellMenu) return;
    cellMenu.hidden = true;
    cellMenuTarget = null;
  }
  function openCellMenu(x, y, node) {
    closeLinkModal();
    cellMenuTarget = node.dataset.id;
    cellMenu.style.left = Math.min(x, window.innerWidth - 200) + 'px';
    cellMenu.style.top = Math.min(y, window.innerHeight - 150) + 'px';
    cellMenu.hidden = false;
  }

  /* ---- Вставка ссылки текстом: только на своем пространстве ---- */
  window.addEventListener('paste', function (e) {
    if (!spaceActive()) return;
    var t = e.target;
    if (t && t.closest && t.closest('input, textarea, [contenteditable]')) return;
    if (linkModal && !linkModal.hidden) return;
    var items = (e.clipboardData && e.clipboardData.items) || [];
    var hasImage = false;
    for (var i = 0; i < items.length; i++) {
      if (items[i].type && items[i].type.indexOf('image/') === 0) { hasImage = true; break; }
    }
    if (hasImage) return; // картинки — только Облачка
    var txt = ((e.clipboardData && e.clipboardData.getData('text')) || '').trim();
    if (!txt) return;
    // Многострочную вставку не роняем молча: берем первую непустую строку.
    var lines = txt.split(/\r?\n/);
    var first = '';
    for (var li = 0; li < lines.length; li++) {
      if (lines[li].trim()) { first = lines[li].trim(); break; }
    }
    if (lines.length > 1) toast('Взята первая ссылка');
    var u = normalizeUrl(first);
    if (!u) return;
    e.preventDefault();
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    openLinkModal(null, u);
  });

  buildLinkModal();
  buildCellMenu();
  renderGrid();
  applyBg();
  // Настройки живут в том же документе: storage-событие самому себе не приходит.
  window.__plusRefresh = function () {
    try { refreshProviderIcon(); } catch (e) {}
    try { applySearchVis(); } catch (e) {}
    try { applyBg(); } catch (e) {}
  };
})();
