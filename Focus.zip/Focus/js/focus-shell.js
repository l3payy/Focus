(function () {
  'use strict';
  // Фокус живет в оболочке: один документ, один paint. Чужих слотов не знаем.
  var FOCUS_SLOT = '[data-space="focus"]';
  function toast(m) {
    try { if (typeof window.__focusToast === 'function') window.__focusToast(m); } catch (e) {}
  }
  function spaceActive() {
    try { return (document.documentElement.dataset.space || 'focus') === 'focus'; }
    catch (e) { return true; }
  }

  /* ---- Тема и провайдер (свой ключ, фолбэк общий) ---- */
  var THEME = 'lilac';
  try { THEME = localStorage.getItem('focus:theme') || 'lilac'; } catch (e) {}
  function searchProvider() {
    try {
      return localStorage.getItem('focus:search:focus')
        || localStorage.getItem('focus:search')
        || 'google';
    } catch (e) { return 'google'; }
  }
  var PROVIDER_ICON = { yandex: 'icon/yandex.svg', google: 'icon/google.svg' };
  function refreshProviderIcon() {
    document.querySelectorAll(FOCUS_SLOT + ' [data-provider-icon]').forEach(function (img) {
      img.src = PROVIDER_ICON[searchProvider()] || PROVIDER_ICON.google;
    });
  }
  function searchOn() {
    try { return localStorage.getItem('focus:searchVis:focus') !== '0'; }
    catch (e) { return true; }
  }
  function applySearchVis() {
    var b = document.querySelector(FOCUS_SLOT + ' [data-search-box]');
    if (b) b.style.display = searchOn() ? '' : 'none';
  }
  applySearchVis();
  window.addEventListener('storage', function (e) {
    if (e.key === 'focus:theme') {
      try { document.documentElement.dataset.theme = localStorage.getItem('focus:theme') || 'lilac'; } catch (err) {}
    }
    if (e.key === 'focus:search' || e.key === 'focus:search:focus') refreshProviderIcon();
    if (e.key === 'focus:searchVis:focus') applySearchVis();
    if (e.key === 'focus:bg:focus') applyBg();
    // Чужая вкладка поменяла сайты — перерисовать, иначе last-write-wins.
    if (e.key === SITES_KEY) renderSites();
  });

  /* ---- Поиск ---- */
  var box = document.querySelector(FOCUS_SLOT + ' [data-search-box]');
  var input = document.querySelector(FOCUS_SLOT + ' [data-search]');
  var goBtn = document.querySelector(FOCUS_SLOT + ' [data-search-go]');
  if (box && input && goBtn) {
    (function initSearch() {
      function doSearch() {
        if (!input.value.trim()) return;
        var q = encodeURIComponent(input.value.trim());
        location.href = searchProvider() === 'yandex'
          ? 'https://ya.ru/search/?text=' + q
          : 'https://www.google.com/search?q=' + q;
      }
      box.addEventListener('mousedown', function (e) {
        if (e.target === input || e.target === goBtn) return;
        e.preventDefault();
        input.focus();
      });
      input.addEventListener('focus', function () { box.classList.add('open'); });
      input.addEventListener('blur', function () {
        if (!input.value.trim()) box.classList.remove('open');
      });
      input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') doSearch();
        if (e.key === 'Escape') { input.value = ''; input.blur(); }
      });
      goBtn.addEventListener('mousedown', function (e) { e.preventDefault(); });
      goBtn.addEventListener('click', doSearch);
    })();
  }

  /* ---- Клавиатура и ПКМ. Навигацию по пространствам делает оболочка,
     здесь только Escape своих окон. ---- */
  window.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && linkModal && !linkModal.hidden) { closeLinkModal(); return; }
    if (e.key === 'Escape' && siteMenu && !siteMenu.hidden) { hideSiteMenu(); return; }
  });
  window.addEventListener('mousedown', function (e) {
    // В одном документе с меню оболочки: клик по меню/окнам не гасим,
    // иначе пункт сдохнет между mousedown и click.
    try {
      if (e.target && e.target.closest && e.target.closest('.ctx-menu, .settings-win, .link-modal, .site-menu')) return;
      if (typeof window.closeCtx === 'function') window.closeCtx();
    } catch (err) {}
  });
  window.addEventListener('mousedown', function (e) {
    if (siteMenu && !siteMenu.hidden && !siteMenu.contains(e.target)) hideSiteMenu();
  });
  window.addEventListener('contextmenu', function (e) {
    if (!e.target.closest || !e.target.closest(FOCUS_SLOT)) return; // чужое — дело оболочки
    var link = e.target.closest('.site');
    if (link) {
      e.preventDefault();
      openSiteMenu(e.clientX, e.clientY, link);
      return;
    }
    if (e.target.closest('img, canvas, input, textarea, a, button, .search, .link-modal')) return;
    e.preventDefault();
    hideSiteMenu();
    try { if (typeof window.openCtx === 'function') window.openCtx(e.clientX, e.clientY); } catch (err) {}
  });

  /* ---- Сайты: только ссылки, мета в localStorage ---- */
  var SITES_KEY = 'focus:sites';
  var SITES_MAX = 16;
  var DEFAULT_SITES = [
    { id: 'site_twitch', url: 'https://www.twitch.tv' },
    { id: 'site_youtube', url: 'https://www.youtube.com' },
    { id: 'site_ymusic', url: 'https://music.yandex.ru' }
  ];
  function loadSites() {
    try {
      var a = JSON.parse(localStorage.getItem(SITES_KEY));
      if (Array.isArray(a)) {
        return a.filter(function (s) {
          return s && typeof s.id === 'string' && typeof s.url === 'string' && normalizeUrl(s.url);
        });
      }
    } catch (e) {}
    try { localStorage.setItem(SITES_KEY, JSON.stringify(DEFAULT_SITES)); } catch (err) {}
    return JSON.parse(JSON.stringify(DEFAULT_SITES));
  }
  function saveSites(items) {
    try { localStorage.setItem(SITES_KEY, JSON.stringify(items)); return true; }
    catch (e) { toast('Хранилище переполнено — не сохранено'); return false; }
  }
  function siteById(id) {
    var all = loadSites();
    for (var k = 0; k < all.length; k++) {
      if (all[k].id === id) return { all: all, m: all[k] };
    }
    return null;
  }
  function hostOf(url) {
    try { return new URL(url).hostname.replace(/^www\./, ''); }
    catch (e) { return ''; }
  }
  // Поиск оформления от полного хоста вверх по домену.
  function siteStyle(host) {
    var h = (host || '').toLowerCase();
    while (h) {
      if (window.SITES_DB && window.SITES_DB[h]) return window.SITES_DB[h];
      var dot = h.indexOf('.');
      if (dot < 0) break;
      h = h.slice(dot + 1);
    }
    return {};
  }
  // s2 без CORS: canvas тонет, dataURL невозможен. Иконки eager'ом,
  // у s2 Cache-Control 7 суток — повторы почти мгновенно из памяти.
  function faviconUrl(url) {
    var h = hostOf(url);
    if (!h) return '';
    // Первичный источник — дакдакго: настоящее детализированное арт.
    // s2 у части пользователей не отвечает (блокеры/сеть) — он вторым номером.
    return 'https://icons.duckduckgo.com/ip3/' + encodeURIComponent(h) + '.ico';
  }
  function normalizeUrl(v) {
    v = (v || '').trim();
    if (!v) return '';
    if (!/^[a-z]+:\/\//i.test(v)) v = 'https://' + v;
    if (/[\s<>]/.test(v)) return '';
    return /^https?:\/\/[^\/\s]+/.test(v) ? v : '';
  }
  function uid() {
    return 'site_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 9);
  }
  function applyIconSize(img, st) {
    if (!st.icon) return;
    img.style.left = '50%';
    img.style.top = '50%';
    img.style.right = 'auto';
    img.style.bottom = 'auto';
    img.style.transform = 'translate(-50%, -50%)';
    if (st.fit === 'long') {
      var doFit = function () {
        if (!img.naturalWidth || !img.naturalHeight) return;
        if (img.naturalWidth >= img.naturalHeight) {
          img.style.width = st.icon + 'px';
          img.style.height = 'auto';
        } else {
          img.style.height = st.icon + 'px';
          img.style.width = 'auto';
        }
      };
      img.addEventListener('load', doFit, { once: true });
      if (img.complete && img.naturalWidth) doFit();
    } else {
      img.style.width = st.icon + 'px';
      img.style.height = 'auto';
    }
  }
  function siteEl(site) {
    // URL ревалидируем: старые записи могли сохранить javascript:.
    var cleanUrl = normalizeUrl(site.url);
    if (!cleanUrl) return document.createComment('bad site');
    var a = document.createElement('a');
    a.className = 'site';
    a.dataset.id = site.id;
    a.href = cleanUrl;
    a.target = '_top';
    var host = hostOf(site.url);
    var st = siteStyle(host);
    if (st.bg) a.style.background = st.bg;
    var letter = document.createElement('span');
    letter.className = 'site-letter';
    letter.textContent = ((host.charAt(0) || '?')).toUpperCase();
    a.appendChild(letter);
    var src = faviconUrl(site.url);
    function netImg() {
      if (!src || navigator.onLine === false) { letter.style.display = 'flex'; return; }
      var img = document.createElement('img');
      img.alt = '';
      img.draggable = false;
      img.loading = 'lazy';
      img.referrerPolicy = 'no-referrer';
      applyIconSize(img, st);
      // Буква показывается только если фавикон не загрузился.
      // s2 для мусора отдает 200 с глобусом — тогда пробуем origin/favicon.ico.
      var done = false;
      var fbTimer = setTimeout(function () {
        if (!done && img.isConnected) { done = true; img.remove(); letter.style.display = 'flex'; }
      }, 8000);
      img.dataset.tryOrigin = '1';
      // Цепочка: дакдакго -> s2 -> origin ico -> буква. s2 у части
      // пользователей мертв, поэтому не первый и не единственный.
      var fbList = [src];
      try {
        fbList.push('https://www.google.com/s2/favicons?domain=' + encodeURIComponent(host) + '&sz=128');
        fbList.push(new URL(site.url).origin + '/favicon.ico');
      } catch (e) {}
      var fbIdx = 0;
      img.addEventListener('load', function () {
        done = true; clearTimeout(fbTimer); img.classList.add('ok');
        if (img.dataset.fromDisk === '1') {
          if (img.src.indexOf('blob:') === 0) { try { URL.revokeObjectURL(img.src); } catch (e) {} }
        } else {
          // Впервые прогрузилась из сети — запечь победителя под хостом.
          try {
            var u = img.getAttribute('src') || '';
            if (u && u.indexOf('blob:') !== 0 && window.FavCache) window.FavCache.bakeHost(host, u);
          } catch (e) {}
        }
      }, { once: true });
      img.addEventListener('error', function h() {
        fbIdx++;
        if (fbIdx < fbList.length) { img.src = fbList[fbIdx]; return; }
        done = true;
        clearTimeout(fbTimer);
        img.remove();
        letter.style.display = 'flex';
      });
      a.appendChild(img);
      // Диск — мгновенно, мимо — сеть (она же запечется в onload выше).
      try {
        if (window.FavCache) {
          window.FavCache.resolveHost(host).then(function (cached) {
            if (!img.isConnected) return;
            if (cached && !img.classList.contains('ok')) {
              img.dataset.fromDisk = '1';
              img.src = cached;
            } else if (!img.getAttribute('src')) {
              img.src = src;
            }
          }, function () { if (img.isConnected && !img.getAttribute('src')) img.src = src; });
        } else { img.src = src; }
      } catch (e) { img.src = src; }
    }
    netImg();
    return a;
  }
  function islandEl() {
    return document.querySelector(FOCUS_SLOT + ' [data-island]');
  }
  function renderSites() {
    var island = islandEl();
    if (!island) return;
    var items = loadSites();
    // Гидрация: синхронная покраска уже стоит — не сносим, иначе блинк.
    // Добиваем только недостающее, лишнее убираем.
    if (island.children.length) {
      var wantIds = items.map(function (s) { return s.id; }).join('|');
      var haveIds = Array.prototype.map.call(
        island.querySelectorAll('.site[data-id]'), function (n) { return n.getAttribute('data-id'); }
      ).join('|');
      if (wantIds === haveIds) {
        items.forEach(function (s) {
          // Узел без картинки (синхронная покраска) меняем на живой:
          // он сам договорится с кешем/сетью уже в DOM.
          var node = island.querySelector('.site[data-id="' + s.id + '"]');
          if (node && !node.querySelector('img')) {
            var fresh = siteEl(s);
            if (fresh.nodeType === 1) node.replaceWith(fresh);
          }
        });
        return;
      }
    }
    island.innerHTML = '';
    items.forEach(function (s) { island.appendChild(siteEl(s)); });
  }
  // Док-эффект: наведенная больше всех, соседи чуть-чуть.
  // Обновления через rAF — без дерганий на частых mousemove.
  // Без анимаций в системе — эффект выключен.
  (function () {
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    var island = islandEl();
    if (!island) return;
    var pendX = 0, raf = 0;
    function paint() {
      raf = 0;
      var links = island.querySelectorAll('.site');
      var h = 0, best = Infinity;
      for (var i = 0; i < links.length; i++) {
        var r = links[i].getBoundingClientRect();
        var c = Math.abs(pendX - (r.left + r.width / 2));
        if (c < best) { best = c; h = i; }
      }
      for (var j = 0; j < links.length; j++) {
        var dd = Math.abs(j - h);
        var s = dd === 0 ? 1.3 : 1;
        links[j].style.transform = 'scale(' + s + ')';
      }
    }
    island.addEventListener('mousemove', function (e) {
      pendX = e.clientX;
      if (!raf) raf = requestAnimationFrame(paint);
    });
    island.addEventListener('mouseleave', function () {
      if (raf) { cancelAnimationFrame(raf); raf = 0; }
      island.querySelectorAll('.site').forEach(function (l) { l.style.transform = ''; });
    });
  })();

  /* ---- Фон: картинка cover + вуаль Beck строго на слоте Фокуса ---- */
  var bgUrl = null, bgReady = false, lqipEl = null;
  function focusSlotEl() {
    return document.querySelector(FOCUS_SLOT);
  }
  function showLqip(thumb) {
    var slot = focusSlotEl();
    if (!slot) return;
    if (lqipEl && lqipEl.isConnected) return; // sync-покраска уже накрыла
    var sync = slot.querySelector('.lqip');
    if (sync) { lqipEl = sync; return; }
    lqipEl = document.createElement('div');
    lqipEl.className = 'lqip';
    lqipEl.style.backgroundImage = 'url("' + thumb + '")';
    slot.appendChild(lqipEl);
  }
  function hideLqip() {
    if (lqipEl && lqipEl.isConnected) {
      var el = lqipEl;
      lqipEl = null;
      el.style.opacity = '0';
      setTimeout(function () { el.remove(); }, 250);
      return;
    }
    lqipEl = null;
    var slot = focusSlotEl();
    if (!slot) return;
    var sync = slot.querySelector('.lqip');
    if (sync) {
      sync.style.opacity = '0';
      setTimeout(function () { sync.remove(); }, 250);
    }
  }
  function makeThumb(blob) {
    return new Promise(function (resolve) {
      var url = URL.createObjectURL(blob);
      var im = new Image();
      im.onload = function () {
        try {
          var s = 32 / Math.max(im.naturalWidth, im.naturalHeight);
          var c = document.createElement('canvas');
          c.width = Math.max(1, Math.round(im.naturalWidth * s));
          c.height = Math.max(1, Math.round(im.naturalHeight * s));
          c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
          resolve(c.toDataURL('image/jpeg', 0.6));
        } catch (e) { resolve(''); }
        URL.revokeObjectURL(url);
      };
      im.onerror = function () { URL.revokeObjectURL(url); resolve(''); };
      im.src = url;
    });
  }
  function bgMeta() {
    try { return JSON.parse(localStorage.getItem('focus:bg:focus')) || null; }
    catch (e) { return null; }
  }
  var bgDbPromise = null;
  function idbBg() {
    if (!bgDbPromise) {
      bgDbPromise = new Promise(function (resolve, reject) {
        var req = indexedDB.open('focus-db', 2);
        req.onupgradeneeded = function () {
          if (!req.result.objectStoreNames.contains('images')) req.result.createObjectStore('images');
          if (!req.result.objectStoreNames.contains('backgrounds')) req.result.createObjectStore('backgrounds');
        };
        req.onsuccess = function () {
          var db = req.result;
          db.onversionchange = function () { db.close(); bgDbPromise = null; };
          resolve(db);
        };
        req.onerror = function () { bgDbPromise = null; reject(req.error); };
        req.onblocked = function () { bgDbPromise = null; reject(new Error('idb blocked')); };
      });
    }
    return bgDbPromise;
  }
  function clearBg() {
    bgReady = false;
    hideLqip();
    var slot = focusSlotEl();
    if (!slot) return;
    slot.style.backgroundImage = '';
    slot.style.removeProperty('--shadow-color');
    if (bgUrl) { try { URL.revokeObjectURL(bgUrl); } catch (e) {} bgUrl = null; }
  }
  function applyBg() {
    var slot = focusSlotEl();
    var meta = bgMeta();
    if (!meta || !slot) { clearBg(); return; }
    // Первый кадр сразу из синхронной заглушки — моргания нет.
    if (meta.thumb && !bgReady) showLqip(meta.thumb);
    var pct = typeof meta.dim === 'number' ? meta.dim : 50;
    idbBg().then(function (db) {
      return new Promise(function (resolve, reject) {
        var rq = db.transaction('backgrounds', 'readonly').objectStore('backgrounds').get('focus');
        rq.onsuccess = function () { resolve(rq.result); };
        rq.onerror = function () { reject(rq.error); };
      });
    }).then(function (blob) {
      if (!blob) { clearBg(); return; }
      if (bgUrl) { try { URL.revokeObjectURL(bgUrl); } catch (e) {} }
      bgUrl = URL.createObjectURL(blob);
      var mix = 'color-mix(in srgb, var(--c-beck) ' + pct + '%, transparent)';
      slot.style.backgroundImage = 'linear-gradient(' + mix + ', ' + mix + '), url("' + bgUrl + '")';
      slot.style.backgroundSize = 'auto, cover';
      slot.style.backgroundPosition = 'center, center';
      slot.style.backgroundRepeat = 'no-repeat';
      if (pct === 0) slot.style.setProperty('--shadow-color', 'rgba(0, 0, 0, 0.5)');
      else slot.style.removeProperty('--shadow-color');
      bgReady = true;
      hideLqip();
      // Миграция: у старых фонов заглушки нет — сделать один раз.
      if (!meta.thumb) {
        makeThumb(blob).then(function (t) {
          if (!t) return;
          var m = bgMeta() || {};
          if (m.thumb) return;
          m.thumb = t;
          try { localStorage.setItem('focus:bg:focus', JSON.stringify(m)); } catch (e) {}
        });
      }
    }, clearBg);
  }

  /* ---- Модалка ссылки: добавить / изменить ---- */
  var linkModal = null, linkScrim = null, linkInput = null, linkTitle = null, editingSiteId = null;
  function buildLinkModal() {
    linkScrim = document.createElement('div');
    linkScrim.className = 'link-scrim';
    linkScrim.hidden = true;
    linkScrim.addEventListener('mousedown', function (e) { e.preventDefault(); closeLinkModal(); });
    document.body.appendChild(linkScrim);
    linkModal = document.createElement('div');
    linkModal.className = 'link-modal';
    linkModal.hidden = true;
    linkModal.innerHTML =
      '<div class="lm-title" data-lm-title>Добавьте ссылку на сайт</div>' +
      '<input type="text" class="lm-input" data-lm-input placeholder="например youtube.com" autocomplete="off" spellcheck="false">' +
      '<div class="lm-btns">' +
      '<button type="button" data-lm-cancel>Отмена</button>' +
      '<button type="button" data-lm-save>Добавить</button>' +
      '</div>';
    document.body.appendChild(linkModal);
    linkTitle = linkModal.querySelector('[data-lm-title]');
    linkInput = linkModal.querySelector('[data-lm-input]');
    linkInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') saveLinkModal();
    });
    var saveBtn = linkModal.querySelector('[data-lm-save]');
    saveBtn.addEventListener('mousedown', function (e) { e.preventDefault(); });
    saveBtn.addEventListener('click', saveLinkModal);
    linkModal.querySelector('[data-lm-cancel]').addEventListener('click', closeLinkModal);
  }
  function openLinkModal(site) {
    hideSiteMenu();
    editingSiteId = site ? site.id : null;
    linkTitle.textContent = site ? 'Изменить ссылку на сайт' : 'Добавьте ссылку на сайт';
    linkInput.value = site ? site.url : '';
    linkScrim.hidden = false;
    linkModal.hidden = false;
    linkInput.focus();
  }
  function closeLinkModal() {
    if (linkModal) linkModal.hidden = true;
    if (linkScrim) linkScrim.hidden = true;
    editingSiteId = null;
  }
  function saveLinkModal() {
    var raw = linkInput.value || '';
    if (raw.length > 2048) { toast('Слишком длинная ссылка'); return; }
    var u = normalizeUrl(raw);
    if (!u) { toast('Вставь ссылку, например youtube.com'); return; }
    var items = loadSites();
    if (editingSiteId) {
      var f = siteById(editingSiteId);
      if (!f) { closeLinkModal(); return; }
      if (f.all.some(function (s) { return s.id !== editingSiteId && s.url === u; })) {
        toast('Уже добавлено');
        return;
      }
      f.m.url = u;
      if (!saveSites(f.all)) return;
      closeLinkModal();
      var old = document.querySelector(FOCUS_SLOT + ' .site[data-id="' + editingSiteId + '"]');
      var fresh = siteEl(f.m);
      if (old) old.replaceWith(fresh);
      else renderSites();
    } else {
      if (items.length >= SITES_MAX) { toast('На Фокусе максимум 16 — остальное в Фокус+'); return; }
      if (items.some(function (s) { return s.url === u; })) { toast('Уже добавлено'); return; }
      var meta = { id: uid(), url: u };
      items.push(meta);
      if (!saveSites(items)) return;
      closeLinkModal();
      var isl = islandEl();
      if (isl) isl.appendChild(siteEl(meta));
    }
  }
  window.addSite = function () { openLinkModal(null); };

  /* ---- Меню ссылки (ПКМ): удалить / изменить ---- */
  var siteMenu = null, siteMenuTarget = null;
  function buildSiteMenu() {
    siteMenu = document.createElement('div');
    siteMenu.className = 'menu site-menu';
    siteMenu.hidden = true;
    siteMenu.innerHTML =
      '<button type="button" class="mrow" data-sm-del>' +
      '<img src="icon/' + THEME + '/deleted.svg" alt="" draggable="false" data-errhide>' +
      '<span>Удалить сайт</span></button>' +
      '<div class="msep"></div>' +
      '<button type="button" class="mrow" data-sm-edit>' +
      '<img src="icon/' + THEME + '/link.svg" alt="" draggable="false" data-errhide>' +
      '<span>Изменить ссылку</span></button>';
    document.body.appendChild(siteMenu);
    siteMenu.querySelector('[data-sm-del]').addEventListener('click', function () {
      var id = siteMenuTarget;
      hideSiteMenu();
      var f = siteById(id);
      if (!f) return;
      saveSites(f.all.filter(function (a) { return a.id !== id; }));
      var node = document.querySelector(FOCUS_SLOT + ' .site[data-id="' + id + '"]');
      if (node) node.remove();
    });
    siteMenu.querySelector('[data-sm-edit]').addEventListener('click', function () {
      var f = siteById(siteMenuTarget);
      hideSiteMenu();
      if (f) openLinkModal(f.m);
    });
  }
  function hideSiteMenu() {
    if (!siteMenu) return;
    siteMenu.hidden = true;
    siteMenuTarget = null;
  }
  function openSiteMenu(x, y, node) {
    closeLinkModal();
    siteMenuTarget = node.dataset.id;
    siteMenu.style.left = Math.min(x, window.innerWidth - 200) + 'px';
    siteMenu.style.top = Math.min(y, window.innerHeight - 150) + 'px';
    siteMenu.hidden = false;
  }

  /* ---- Вставка ссылки текстом: только на своем пространстве ---- */
  window.addEventListener('paste', function (e) {
    if (!spaceActive()) return;
    var t = e.target;
    if (t && t.closest && t.closest('input, textarea, [contenteditable]')) return;
    if (linkModal && !linkModal.hidden) return;
    var items = (e.clipboardData && e.clipboardData.items) || [];
    var hasImage = false;
    for (var i = 0; i < items.length; i++) {
      if (items[i].type && items[i].type.indexOf('image/') === 0) { hasImage = true; break; }
    }
    if (hasImage) return; // картинки — только Облачка
    var txt = ((e.clipboardData && e.clipboardData.getData('text')) || '').trim();
    if (!txt) return;
    // Многострочную вставку не роняем молча: берем первую непустую строку.
    var lines = txt.split(/\r?\n/);
    var first = '';
    for (var li = 0; li < lines.length; li++) {
      if (lines[li].trim()) { first = lines[li].trim(); break; }
    }
    if (lines.length > 1) toast('Взята первая ссылка');
    var u = normalizeUrl(first);
    if (!u) return;
    e.preventDefault();
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    openLinkModal(null);
    linkInput.value = u;
  });

  buildLinkModal();
  buildSiteMenu();
  renderSites();
  applyBg();
  // Настройки живут в том же документе: storage-событие самому себе не приходит,
  // поэтому оболочка дергает refresh напрямую после Сохранить.
  window.__focusRefresh = function () {
    try { refreshProviderIcon(); } catch (e) {}
    try { applySearchVis(); } catch (e) {}
    try { applyBg(); } catch (e) {}
  };
})();
