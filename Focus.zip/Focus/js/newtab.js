
  // Оболочка: навигация + хром. Контента пространств здесь нет вообще.
  // Пространства: cloud (вверх) -> focus (центр) -> focusplus (вниз).
  const ORDER = ['cloud', 'focus', 'focusplus'];
  // Фокус и Фокус+ живут в оболочке (монолит, без фрейма). Фрейм только cloud.
  const FILES = { cloud: 'cloud.html' };
  const pager = document.getElementById('pager');
  const toastEl = document.getElementById('toast');
  const frames = {}; // space -> iframe element

  let current = ORDER.indexOf(window.__FOCUS_INITIAL_SPACE || 'focus');
  if (current < 0) current = 1;

  let toastTimer = null;
  function toast(msg) {
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('show'), 2600);
  }
  window.__focusToast = toast;

  // Фрейм создается по первому визиту и живет дальше.
  // Скрытый фрейм не в фокусе: его слушатели и вставка мертвы конструктивно.
  const slots = {};
  document.querySelectorAll('.slot').forEach((s) => { slots[s.dataset.space] = s; });
  function dropPlaceholder(space) {
    // Слепок и фрейм пиксель-в-пиксель: снимаем после двух кадров фрейма.
    try {
      const sl = slots[space];
      if (!sl) return;
      const ph = sl.querySelector('[data-ph], [data-search-snap]');
      if (!ph) return;
      requestAnimationFrame(() => requestAnimationFrame(() => { try { ph.remove(); } catch (e) {} }));
    } catch (e) {}
  }
  // Провайдер свой у каждого пространства: при переходе иконку обновить,
  // иначе останется прошлая (фреймы живут дальше и сами не перечитывают).
  function refreshSpaceProvider(space) {
    try {
      if (space === 'focus') {
        if (typeof window.__focusRefresh === 'function') window.__focusRefresh();
        return;
      }
      if (space === 'focusplus') {
        if (typeof window.__plusRefresh === 'function') window.__plusRefresh();
        return;
      }
      const f = frames[space];
      if (!f) return;
      const go = () => {
        try {
          const w = f.contentWindow;
          if (w && typeof w.__refreshProvider === 'function') w.__refreshProvider();
        } catch (e) {}
      };
      try {
        if (f.contentDocument && f.contentDocument.readyState === 'complete') go();
        else f.addEventListener('load', go, { once: true });
      } catch (e) { go(); }
    } catch (e) {}
  }
  // Облачка сообщают о готовности статики: показать фрейм, снять слепок.
  // Слепок снимаем только здесь (не по load), иначе будет кадр пустоты.
  // Страховка: если фрейм молчит (упал IDB/JS), показать через 3с после load.
  function cloudReady() {
    try {
      const sl = slots.cloud;
      if (!sl) return;
      sl.dataset.ready = '1';
      dropPlaceholder('cloud');
    } catch (e) {}
  }
  window.__cloudReady = cloudReady;
  function attachWheel(f, space) {
    try {
      const done = () => {
        try { f.contentWindow.addEventListener('wheel', onWheel, { passive: true }); } catch (e) {}
        if (space && space !== 'cloud') dropPlaceholder(space);
        if (space === 'cloud') setTimeout(() => { try { cloudReady(); } catch (e) {} }, 3000);
      };
      if (f.contentDocument && f.contentDocument.readyState === 'complete') done();
      else f.addEventListener('load', done, { once: true });
    } catch (e) {}
  }
  // Синхронный фрейм из boot-pager уже в DOM — подхватить, не дублировать.
  // Поздний фрейм (создан после paint) ловим наблюдателем.
  document.querySelectorAll('.slot iframe').forEach((f) => {
    try {
      const sp = f.parentElement && f.parentElement.dataset.space;
      if (sp) { frames[sp] = f; attachWheel(f, sp); }
    } catch (e) {}
  });
  try {
    const mo = new MutationObserver((muts) => {
      muts.forEach((m) => {
        (m.addedNodes || []).forEach((n) => {
          try {
            if (n && n.tagName === 'IFRAME') {
              const sp = n.parentElement && n.parentElement.dataset.space;
              if (sp && !frames[sp]) { frames[sp] = n; attachWheel(n, sp); }
            }
          } catch (e) {}
        });
      });
    });
    Object.values(slots).forEach((sl) => { try { mo.observe(sl, { childList: true }); } catch (e) {} });
  } catch (e) {}
  // Фокус только в загруженный документ, иначе Ctrl+V уйдет в старый.
  function focusFrame(space) {
    const f = frames[space];
    if (!f) return;
    const go = () => { try { f.contentWindow.focus(); } catch (e) {} };
    try {
      if (f.contentDocument && f.contentDocument.readyState === 'complete') go();
      else f.addEventListener('load', go, { once: true });
    } catch (e) { go(); }
  }
  function ensureFrame(space) {
    if (space === 'focus' || space === 'focusplus') return null; // монолит, фрейм не нужен
    if (frames[space]) return frames[space];
    const slot = slots[space];
    if (!slot) return null;
    const existing = slot.querySelector('iframe');
    if (existing) { frames[space] = existing; attachWheel(existing, space); return existing; }
    const f = document.createElement('iframe');
    f.setAttribute('title', space);
    // load-слушатель раньше src: при кэше load иначе опередит.
    attachWheel(f, space);
    f.src = FILES[space];
    slot.appendChild(f);
    frames[space] = f;
    return f;
  }

  let hideTimer = null;
  function apply(instant) {
    if (instant) pager.classList.remove('anim');
    else pager.classList.add('anim');
    pager.style.transform = `translateY(${-current * 100}vh)`;
    try { localStorage.setItem('focus:lastSpace', ORDER[current]); } catch (e) {}
    try { document.documentElement.dataset.space = ORDER[current]; } catch (e) {}
    // Рисуется только активное. Уходящее гасим после долета, чтобы слайд был виден.
    const active = ORDER[current];
    Object.values(slots).forEach((s) => {
      if (s.dataset.space === active) s.classList.remove('slot-hidden');
    });
    clearTimeout(hideTimer);
    const hideRest = () => {
      const now = ORDER[current];
      Object.values(slots).forEach((s) => {
        if (s.dataset.space !== now) s.classList.add('slot-hidden');
      });
    };
    if (instant) hideRest();
    else {
      const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      hideTimer = setTimeout(hideRest, reduceMotion ? 0 : 320);
    }
  }

  let navigating = false;
  async function goTo(space) {
    const idx = ORDER.indexOf(space);
    if (idx < 0 || idx === current || navigating) return;
    navigating = true;
    try {
      blurFrames();
      current = idx;
      ensureFrame(space);
      apply(false);
      // Фокус едет за пространством — иначе Ctrl+V уйдет в старый документ.
      focusFrame(space);
      refreshSpaceProvider(space);
    } finally {
      setTimeout(() => { navigating = false; }, 320);
    }
  }
  // Фреймы зовут parent.nav(1/-1) для стрелок/PgUp/PgDn.
  function nav(dir) {
    if (Date.now() < cooldownUntil) return;
    goTo(ORDER[Math.min(2, Math.max(0, current + dir))]);
  }
  function blurFrames() {
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    Object.values(frames).forEach((f) => {
      try { f.contentWindow.blur(); } catch (e) {}
    });
  }
  window.goTo = goTo;
  window.nav = nav;

  // ---- Уверенный скролл: 2-3 щелчка в одну сторону = переход ----
  let acc = 0, accTimer = null, cooldownUntil = 0;
  function resetAcc() { acc = 0; clearTimeout(accTimer); accTimer = null; }
  function onWheel(e) {
    if (window.__focusCardDrag) return; // ведут карточку с колесом — не переключать
    if (window.__cloudBusy) return; // рисуют — не переключать
    const now = Date.now();
    if (now < cooldownUntil) return;
    if (e.target && e.target.closest && e.target.closest('input, textarea, [contenteditable]')) return;
    let d = e.deltaY;
    if (e.deltaMode === 1) d *= 16;
    if (Math.abs(d) < 2) return;
    if (acc !== 0 && Math.sign(d) !== Math.sign(acc)) acc = 0;
    acc += d;
    clearTimeout(accTimer);
    accTimer = setTimeout(resetAcc, 300);
    const dir = acc > 0 ? 1 : -1;
    // Слабый скролл: заранее создать соседний фрейм, чтобы первый визит не подвисал.
    if (Math.abs(acc) > 60 && Math.abs(acc) < 250) {
      const neighbor = ORDER[current + dir];
      if (neighbor) ensureFrame(neighbor);
    }
    if (Math.abs(acc) >= 250) {
      resetAcc();
      const next = ORDER[current + dir];
      if (next) { cooldownUntil = now + 600; goTo(next); }
    }
  }
  window.addEventListener('wheel', onWheel, { passive: true });

  // ---- Хром: почта, ПКМ-меню, настройки ----
  const THEME = document.documentElement.dataset.theme || 'lilac';
  document.querySelectorAll('[data-theme-icon]').forEach((img) => {
    img.src = `icon/${THEME}/${img.dataset.themeIcon}.svg`;
  });
  function mailStored() {
    try { return (localStorage.getItem('focus:mailUrl') || '').trim(); }
    catch (e) { return ''; }
  }
  function refreshMail() {
    const a = document.querySelector('[data-mail]');
    if (!a) return;
    const u = mailStored();
    const on = /^https?:\/\/.+/.test(u);
    if (on) a.href = u;
    else a.removeAttribute('href');
    a.hidden = !on;
  }
  function normalizeUrl(v) {
    v = (v || '').trim();
    if (!v) return '';
    if (!/^[a-z]+:\/\//i.test(v)) v = 'https://' + v;
    return /^https?:\/\/.+/.test(v) ? v : '';
  }
  const ctxMenu = document.querySelector('[data-ctx]');
  // ---- Единое ПКМ-меню: вид один, наполнение по пространству ----
  const CTX_MENUS = {
    cloud: [
      { icon: 'text', label: 'Добавить текст', act: 'todoText' },
      { sep: true },
      { icon: 'pen', label: 'Рисовать', act: 'todoDraw' },
      { sep: true },
      { icon: 'eraser', label: 'Очистить всё', act: 'clear' },
      { sep: true },
      { icon: 'settings', label: 'Настройки', act: 'settings' }
    ],
    focus: [
      { icon: 'add', label: 'Добавить сайт', act: 'addSite' },
      { sep: true },
      { icon: 'settings', label: 'Настройки', act: 'settings' }
    ],
    focusplus: [
      { icon: 'add', label: 'Добавить сайт', act: 'addPlusSite' },
      { sep: true },
      { icon: 'settings', label: 'Настройки', act: 'settings' }
    ]
  };
  // Фреймы зовут parent.openCtx(x, y) — координаты уже в системе оболочки.
  function openCtx(x, y) {
    if (!setsWin.hidden) return; // окно настроек открыто — меню не вызываем
    const items = CTX_MENUS[ORDER[current]] || CTX_MENUS.focus;
    let html = '';
    items.forEach((it) => {
      if (it.sep) { html += '<div class="msep"></div>'; return; }
      html += '<button type="button" class="mrow" data-act="' + it.act + '">' +
        '<img src="icon/' + THEME + '/' + it.icon + '.svg" alt="" draggable="false" data-errhide>' +
        '<span>' + it.label + '</span></button>';
    });
    ctxMenu.innerHTML = html;
    ctxMenu.style.left = Math.min(x, innerWidth - 200) + 'px';
    ctxMenu.style.top = Math.min(y, innerHeight - 120) + 'px';
    ctxMenu.hidden = false;
  }
  ctxMenu.addEventListener('click', (e) => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    ctxAct(b.dataset.act);
  });
  function ctxAct(act) {
    if (act === 'settings') { openSetsWin(); return; }
    if (act === 'todoText') {
      closeCtx();
      const cf = frames.cloud;
      if (cf) { try { cf.contentWindow.addCloudText(); } catch (err) {} }
      return;
    }
    if (act === 'todoDraw') {
      closeCtx();
      let cf = frames.cloud;
      if (!cf) cf = ensureFrame('cloud');
      const go = () => { try { cf.contentWindow.startDraw(); } catch (err) {} };
      try {
        if (cf.contentDocument && cf.contentDocument.readyState === 'complete') go();
        else cf.addEventListener('load', go, { once: true });
      } catch (err) { go(); }
      return;
    }
    if (act === 'addSite') {
      closeCtx();
      try { if (typeof window.addSite === 'function') window.addSite(); } catch (err) {}
      return;
    }
    if (act === 'addPlusSite') {
      closeCtx();
      try { if (typeof window.addPlusSite === 'function') window.addPlusSite(); } catch (err) {}
      return;
    }
    if (act !== 'clear') return;
    closeCtx();
    const f = frames.cloud;
    if (!f) return;
    try { f.contentWindow.askClearCloud(); } catch (err) {}
  }
  window.addEventListener('contextmenu', (e) => {
    if (e.target.closest('img, canvas, input, textarea, a, button, .mail-link, .settings-panel, .ctx-menu')) return;
    e.preventDefault();
    openCtx(e.clientX, e.clientY);
  });
  window.addEventListener('mousedown', (e) => {
    if (!ctxMenu.hidden && !e.target.closest('.ctx-menu')) closeCtx();
  });
  window.addEventListener('blur', () => { ctxMenu.hidden = true; });
  window.addEventListener('keydown', (e) => {
    if (e.target && e.target.closest && e.target.closest('input, textarea, [contenteditable]')) {
      if (e.key === 'Escape' && e.target.blur) e.target.blur();
      return;
    }
    if (e.key === 'Escape') {
      closeCtx();
      if (!setsWin.hidden) closeSetsWin();
      return;
    }
    if (e.key === 'PageDown' || e.key === 'ArrowDown') { e.preventDefault(); nav(1); }
    if (e.key === 'PageUp' || e.key === 'ArrowUp') { e.preventDefault(); nav(-1); }
  });
  // ---- Дата: хром оболочки, включение из настроек, по дефолту выключена ----
  function dateOn() {
    try { return localStorage.getItem('focus:dateOn') === '1'; }
    catch (e) { return false; }
  }
  function renderDate() {
    const w = document.querySelector('[data-date]');
    if (!w) return;
    if (!dateOn()) { w.hidden = true; return; }
    const now = new Date();
    const d = now.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' });
    let wd = now.toLocaleDateString('ru-RU', { weekday: 'long' });
    wd = wd.charAt(0).toUpperCase() + wd.slice(1);
    document.querySelector('[data-date-text]').textContent = d;
    document.querySelector('[data-date-week]').textContent = wd;
    w.hidden = false;
    // Перерисовать после полуночи.
    const ms = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1).getTime() - now.getTime();
    clearTimeout(renderDate._t);
    renderDate._t = setTimeout(renderDate, ms + 1000);
  }
  renderDate();
  window.openCtx = openCtx;
  // Фреймы гасят/возвращают хром под своими модалками.
  function setChromeDim(on) {
    document.querySelectorAll('[data-mail], [data-date]').forEach((el) => {
      el.classList.toggle('chrome-dim', !!on);
    });
  }
  window.setChromeDim = setChromeDim;
  function closeCtx() {
    ctxMenu.hidden = true;
  }
  window.closeCtx = closeCtx;
  // ---- Окно настроек: вкладки переключаются, правая часть позже ----
  const setsWin = document.querySelector('[data-sets-win]');
  const setsScrim = document.querySelector('[data-sets-scrim]');
  function openSetsWin() {
    closeCtx();
    clearTimeout(setsCloseTimer);
    setsWin.classList.remove('closing');
    // Префилл из хранилища.
    try {
      document.querySelector('[data-sets-mail]').value = mailStored();
      const dOn = dateOn();
      const sw = document.querySelector('[data-sets-date]');
      sw.classList.toggle('on', dOn);
      sw.setAttribute('aria-checked', dOn ? 'true' : 'false');
      const acc = localStorage.getItem('focus:accent') || 'DDD3FF';
      document.querySelectorAll('[data-accent]').forEach((b) => {
        b.classList.toggle('sel', b.dataset.accent === acc);
      });
      document.querySelectorAll('[data-prov]').forEach((row) => {
        const p = spaceProvider(row.dataset.prov);
        row.querySelectorAll('.prov').forEach((b) => b.classList.toggle('sel', b.dataset.p === p));
      });
      document.querySelectorAll('[data-searchvis]').forEach((block) => {
        const on = spaceSearchOn(block.dataset.searchvis);
        const sw = block.querySelector('[data-sets-searchvis]');
        if (sw) {
          sw.classList.toggle('on', on);
          sw.setAttribute('aria-checked', on ? 'true' : 'false');
        }
      });
      bgStaging.focus = null;
      bgStaging.focusplus = null;
      refreshBgRow('focus');
      refreshBgRow('focusplus');
    } catch (e) {}
    setsScrim.hidden = false;
    setsWin.hidden = false;
  }
  let setsCloseTimer = null;
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function closeSetsWin() {
    if (setsWin.hidden || setsWin.classList.contains('closing')) return;
    if (reduceMotion) {
      setsWin.hidden = true;
      setsScrim.hidden = true;
      return;
    }
    setsWin.classList.add('closing');
    clearTimeout(setsCloseTimer);
    setsCloseTimer = setTimeout(() => {
      setsWin.hidden = true;
      setsWin.classList.remove('closing');
      setsScrim.hidden = true;
    }, 200);
  }
  document.querySelector('[data-sets-tabs]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-stab]');
    if (!b) return;
    document.querySelectorAll('[data-stab]').forEach((t) => t.classList.toggle('active', t === b));
    document.querySelectorAll('[data-spane]').forEach((p) => { p.hidden = p.dataset.spane !== b.dataset.stab; });
  });
  document.querySelector('[data-sets-date]').addEventListener('click', (e) => {
    const sw = e.currentTarget;
    const on = !sw.classList.contains('on');
    sw.classList.toggle('on', on);
    sw.setAttribute('aria-checked', on ? 'true' : 'false');
  });
  document.querySelectorAll('[data-sets-searchvis]').forEach((sw) => {
    sw.addEventListener('click', () => {
      const on = !sw.classList.contains('on');
      sw.classList.toggle('on', on);
      sw.setAttribute('aria-checked', on ? 'true' : 'false');
    });
  });
  document.querySelector('[data-sets-accents]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-accent]');
    if (!b) return;
    document.querySelectorAll('[data-accent]').forEach((t) => t.classList.toggle('sel', t === b));
  });
  // Поиск виден поключно: focus:searchVis:<space> === '0' скрывает. Дефолт виден.
  function spaceSearchOn(space) {
    try { return localStorage.getItem('focus:searchVis:' + space) !== '0'; }
    catch (e) { return true; }
  }
  // Провайдер поключно: focus:search:<space>, фолбэк — общий и гугл.
  function spaceProvider(space) {
    try {
      return localStorage.getItem('focus:search:' + space)
        || localStorage.getItem('focus:search')
        || 'google';
    } catch (e) { return 'google'; }
  }
  document.querySelector('[data-sets-right]').addEventListener('click', (e) => {
    const pv = e.target.closest('[data-prov] .prov');
    if (pv) {
      pv.parentElement.querySelectorAll('.prov').forEach((t) => t.classList.toggle('sel', t === pv));
      return;
    }
    const b = e.target.closest('.linkbtn');
    if (!b) return;
    if (b.dataset.link) location.href = b.dataset.link;
    else toast('Скоро будет');
  });
  // ---- Фон пространств: блоб в IDB, dim в мете, применение — только по Сохранить ----
  const BG_SPACES = ['focus', 'focusplus'];
  const bgStaging = { focus: null, focusplus: null }; // {blob, dim} | {del:true} | null
  const bgPrevUrls = {};
  // Один коннект на документ: иначе копятся открытые и блокируют апгрейды.
  let bgDbPromise = null;
  function idbBg() {
    if (!bgDbPromise) {
      bgDbPromise = new Promise((resolve, reject) => {
        const req = indexedDB.open('focus-db', 2);
        req.onupgradeneeded = () => {
          if (!req.result.objectStoreNames.contains('images')) req.result.createObjectStore('images');
          if (!req.result.objectStoreNames.contains('backgrounds')) req.result.createObjectStore('backgrounds');
        };
        req.onsuccess = () => {
          const db = req.result;
          db.onversionchange = () => { db.close(); bgDbPromise = null; };
          resolve(db);
        };
        req.onerror = () => { bgDbPromise = null; reject(req.error); };
        req.onblocked = () => { bgDbPromise = null; reject(new Error('idb blocked')); };
      });
    }
    return bgDbPromise;
  }
  function idbBgReq(db, mode, fn) {
    return new Promise((resolve, reject) => {
      const rq = fn(db.transaction('backgrounds', mode).objectStore('backgrounds'));
      rq.onsuccess = () => resolve(rq.result);
      rq.onerror = () => reject(rq.error);
    });
  }
  function bgMeta(space) {
    try { return JSON.parse(localStorage.getItem('focus:bg:' + space)) || null; }
    catch (e) { return null; }
  }
  // Стейл-ответы отбрасываем: юзер мог уже загрузить/удалить другой файл.
  const bgRowGen = {};
  function refreshBgRow(space) {
    const block = document.querySelector('[data-bgblock="' + space + '"]');
    if (!block) return;
    const prev = block.querySelector('[data-bg-prev]');
    const prevImg = prev.querySelector('img');
    const del = block.querySelector('[data-bg-del]');
    const slider = block.querySelector('[data-bg-slider]');
    const range = block.querySelector('[data-bg-range]');
    const cur = block.querySelector('[data-bg-cur]');
    const showEmpty = () => {
      if (bgPrevUrls[space]) { URL.revokeObjectURL(bgPrevUrls[space]); bgPrevUrls[space] = null; }
      prev.hidden = true; del.hidden = true; slider.hidden = true;
    };
    const showFull = (url, dim) => {
      if (bgPrevUrls[space]) URL.revokeObjectURL(bgPrevUrls[space]);
      bgPrevUrls[space] = url;
      prevImg.src = url;
      prev.hidden = false; del.hidden = false; slider.hidden = false;
      range.value = String(dim);
      cur.textContent = dim + '%';
    };
    const st = bgStaging[space];
    if (st && st.del) { showEmpty(); return; }
    if (st && st.blob) { showFull(URL.createObjectURL(st.blob), st.dim); return; }
    const meta = bgMeta(space);
    if (!meta) { showEmpty(); return; }
    const dim = typeof meta.dim === 'number' ? meta.dim : 50;
    const gen = (bgRowGen[space] || 0) + 1;
    bgRowGen[space] = gen;
    idbBg().then(
      (db) => idbBgReq(db, 'readonly', (s) => s.get(space)),
      showEmpty
    ).then((blob) => {
      if (gen !== bgRowGen[space]) return;
      if (!blob) { showEmpty(); return; }
      showFull(URL.createObjectURL(blob), dim);
    }, showEmpty);
  }
  function processBgFile(file) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        try {
          const MAX = 1920;
          const s = Math.min(1, MAX / Math.max(img.naturalWidth, img.naturalHeight));
          const c = document.createElement('canvas');
          c.width = Math.max(1, Math.round(img.naturalWidth * s));
          c.height = Math.max(1, Math.round(img.naturalHeight * s));
          c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
          URL.revokeObjectURL(url);
          c.toBlob((b) => {
            if (!b) { reject(new Error('toblob')); return; }
            // LQIP-заглушка 32px в мету — первый кадр без моргания.
            const ts = 32 / Math.max(c.width, c.height);
            const tc = document.createElement('canvas');
            tc.width = Math.max(1, Math.round(c.width * ts));
            tc.height = Math.max(1, Math.round(c.height * ts));
            tc.getContext('2d').drawImage(c, 0, 0, tc.width, tc.height);
            resolve({ blob: b, thumb: tc.toDataURL('image/jpeg', 0.6) });
          }, 'image/webp', 0.85);
        } catch (e) { URL.revokeObjectURL(url); reject(e); }
      };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('img')); };
      img.src = url;
    });
  }
  const bgFile = document.createElement('input');
  bgFile.type = 'file';
  bgFile.accept = 'image/png,image/jpeg,image/webp';
  bgFile.hidden = true;
  document.body.appendChild(bgFile);
  let bgPendingSpace = null;
  bgFile.addEventListener('change', () => {
    const f = bgFile.files && bgFile.files[0];
    bgFile.value = '';
    if (!f || !bgPendingSpace) return;
    if (f.type !== 'image/png' && f.type !== 'image/jpeg' && f.type !== 'image/webp') {
      toast('Только PNG, JPEG и WebP');
      return;
    }
    processBgFile(f).then((r) => {
      const space = bgPendingSpace;
      const prev = bgMeta(space);
      bgStaging[space] = { blob: r.blob, thumb: r.thumb, dim: prev && typeof prev.dim === 'number' ? prev.dim : 50 };
      refreshBgRow(space);
    }, () => toast('Не вышло загрузить фон'));
  });
  document.querySelectorAll('[data-bgblock]').forEach((block) => {
    const space = block.dataset.bgblock;
    block.querySelector('[data-bg-upload]').addEventListener('click', () => {
      bgPendingSpace = space;
      bgFile.click();
    });
    block.querySelector('[data-bg-del]').addEventListener('click', () => {
      bgStaging[space] = { del: true };
      refreshBgRow(space);
    });
    block.querySelector('[data-bg-range]').addEventListener('input', (e) => {
      const dim = parseInt(e.target.value, 10) || 0;
      block.querySelector('[data-bg-cur]').textContent = dim + '%';
      const cur = bgStaging[space] || {};
      bgStaging[space] = { blob: cur.blob || null, thumb: cur.thumb || null, del: !!cur.del, dim: dim };
    });
  });
  function commitBgStaging() {
    const jobs = BG_SPACES.map((space) => {
      const st = bgStaging[space];
      if (!st) return Promise.resolve();
      if (st.del) {
        return idbBg().then(
          (db) => idbBgReq(db, 'readwrite', (s) => s.delete(space)),
          () => {}
        ).then(() => {
          try { localStorage.removeItem('focus:bg:' + space); } catch (e) {}
        });
      }
      if (st.blob) {
        return idbBg().then(
          (db) => idbBgReq(db, 'readwrite', (s) => s.put(st.blob, space)),
          () => { toast('Не вышло сохранить фон'); throw new Error('idb'); }
        ).then(() => {
          try { localStorage.setItem('focus:bg:' + space, JSON.stringify({ rev: Date.now(), dim: st.dim, thumb: st.thumb || '' })); }
          catch (e) { toast('Настройки фона не сохранились'); }
        });
      }
      const meta = bgMeta(space) || {};
      meta.dim = st.dim;
      try { localStorage.setItem('focus:bg:' + space, JSON.stringify(meta)); }
      catch (e) { toast('Настройки фона не сохранились'); }
      return Promise.resolve();
    });
    return Promise.all(jobs).then(() => {
      bgStaging.focus = null;
      bgStaging.focusplus = null;
    });
  }
  // Сохранить: применить всё, закрыть окно.
  document.querySelector('[data-sets-save]').addEventListener('click', () => {
    try {
      const u = normalizeUrl(document.querySelector('[data-sets-mail]').value);
      if (u) localStorage.setItem('focus:mailUrl', u);
      else localStorage.removeItem('focus:mailUrl');
      const dOn = document.querySelector('[data-sets-date]').classList.contains('on');
      localStorage.setItem('focus:dateOn', dOn ? '1' : '0');
      const acc = document.querySelector('[data-accent].sel');
      if (acc) localStorage.setItem('focus:accent', acc.dataset.accent);
      document.querySelectorAll('[data-prov]').forEach((row) => {
        const sel = row.querySelector('.prov.sel');
        if (sel) localStorage.setItem('focus:search:' + row.dataset.prov, sel.dataset.p);
      });
      document.querySelectorAll('[data-searchvis]').forEach((block) => {
        const sw = block.querySelector('[data-sets-searchvis]');
        if (sw) localStorage.setItem('focus:searchVis:' + block.dataset.searchvis, sw.classList.contains('on') ? '1' : '0');
      });
    } catch (e) {}
    refreshMail();
    renderDate();
    // Слепки поиска тоже за провайдером — иначе покажут старый до перезагрузки.
    try {
      document.querySelectorAll('.slot').forEach((sl) => {
        const pi = sl.querySelector('[data-search-snap] [data-provider-icon]');
        if (pi) pi.src = spaceProvider(sl.dataset.space) === 'yandex' ? 'icon/yandex.svg' : 'icon/google.svg';
      });
    } catch (e) {}
    commitBgStaging().then(() => {
      try { if (typeof window.__focusRefresh === 'function') window.__focusRefresh(); } catch (e) {}
      try { if (typeof window.__plusRefresh === 'function') window.__plusRefresh(); } catch (e) {}
      closeSetsWin();
    }, closeSetsWin);
  });
  refreshMail();

  // ---- Старт: фрейм уже едет сам (после paint), здесь не создаем ----
  // Иначе свели бы на нет весь смысл слепка: конкуренция до первого кадра.
  const firstFrame = frames[ORDER[current]] || null;
  apply(true);
  if (firstFrame) { try { firstFrame.contentWindow.focus(); } catch (e) {} }
  requestAnimationFrame(() => pager.classList.add('anim'));


// data-errhide imgs hide on error (CSP-safe, no inline handlers).
document.addEventListener('error', function (e) {
  var t = e.target;
  if (t && t.tagName === 'IMG' && t.hasAttribute && t.hasAttribute('data-errhide')) { t.style.display = 'none'; }
}, true);