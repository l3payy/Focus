
(function () {
  try {
    var t = localStorage.getItem('focus:theme');
    if (t !== 'lilac') t = 'lilac';
    document.documentElement.dataset.theme = t;
  } catch (e) {}
})();
