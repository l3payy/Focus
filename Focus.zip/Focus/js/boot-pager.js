// Синхронный старт пейджера до first paint: позиция + настоящий остров Фокуса.
// Фокус живет в оболочке (один документ = один paint): поиск — статика в разметке,
// ячейки — отсюда из localStorage. Фрейм для Фокуса не создается вообще.
// Облачка/Плюс во фреймах: их документы стартуют после paint.
(function () {
  try {
    var s = window.__FOCUS_INITIAL_SPACE || 'focus';
    var FILES = { cloud: 'cloud.html' };
    var ORDER = ['cloud', 'focus', 'focusplus'];
    var idx = ORDER.indexOf(s);
    if (idx < 0) idx = 1;
    var pager = document.getElementById('pager');
    if (pager) pager.style.transform = 'translateY(' + (-idx * 100) + 'vh)';
    var slots = document.querySelectorAll('.slot');
    var activeSlot = null;
    for (var i = 0; i < slots.length; i++) {
      var sp = slots[i].getAttribute('data-space');
      if (sp !== s) {
        slots[i].classList.add('slot-hidden');
      } else {
        activeSlot = slots[i];
      }
    }
    if (s === 'focus' && activeSlot) {
      try { paintFocusIsland(activeSlot); } catch (e) {}
    }
    if (s === 'focusplus' && activeSlot) {
      try { paintPlusGrid(activeSlot); } catch (e) {}
    }
    // Слепок поиска для Облачков: статика в первом кадре,
    // фрейм снимает при готовности. Фокус и Плюс — настоящие, им не надо.
    try {
      paintSearchSnap('cloud');
    } catch (e) {}
    // Чужой фрейм — только после paint, чтобы не драться за первый кадр.
    // Фрейм остался только у Облачков; Фокус и Плюс — монолит в оболочке.
    if (s !== 'focus' && s !== 'focusplus') {
      try {
        var mkFrame = function () {
          try {
            if (!activeSlot || activeSlot.querySelector('iframe')) return;
            var f = document.createElement('iframe');
            f.setAttribute('title', s);
            f.src = FILES[s];
            activeSlot.appendChild(f);
          } catch (e) {}
        };
        if (window.requestAnimationFrame) requestAnimationFrame(function () { setTimeout(mkFrame, 0); });
        else setTimeout(mkFrame, 0);
      } catch (e) {}
    }
  } catch (e) {}

  function paintFocusIsland(slot) {
    var DEFAULTS = [
      { id: 'site_twitch', url: 'https://www.twitch.tv' },
      { id: 'site_youtube', url: 'https://www.youtube.com' },
      { id: 'site_ymusic', url: 'https://music.yandex.ru' }
    ];
    function norm(v) {
      v = (v || '').trim();
      if (!v) return '';
      if (!/^[a-z]+:\/\//i.test(v)) v = 'https://' + v;
      if (/[\s<>]/.test(v)) return '';
      return /^https?:\/\/[^\/\s]+/.test(v) ? v : '';
    }
    function hostOf(url) {
      try { return new URL(url).hostname.replace(/^www\./, '').toLowerCase(); }
      catch (e) { return ''; }
    }
    // Провайдер — первым делом, пока краска не встала.
    try {
      var prov = 'google';
      try { prov = localStorage.getItem('focus:search:focus') || localStorage.getItem('focus:search') || 'google'; } catch (e) {}
      var pi = slot.querySelector('[data-provider-icon]');
      if (pi) pi.src = prov === 'yandex' ? 'icon/yandex.svg' : 'icon/google.svg';
    } catch (e) {}
    // Поиск выключен — прячем синхронно, чтобы не мигнул.
    try {
      var off = false;
      try { off = localStorage.getItem('focus:searchVis:focus') === '0'; } catch (e) {}
      if (off) {
        var sb = slot.querySelector('[data-search-box]');
        if (sb) sb.style.display = 'none';
      }
    } catch (e) {}
    var island = slot.querySelector('[data-island]');
    if (!island || island.children.length) return;
    var sites = null;
    try {
      var a = JSON.parse(localStorage.getItem('focus:sites'));
      if (Array.isArray(a)) {
        sites = a.filter(function (x) { return x && typeof x.id === 'string' && typeof x.url === 'string' && norm(x.url); });
        if (!sites.length) sites = null;
      }
    } catch (e) { sites = null; }
    if (!sites) sites = DEFAULTS;
    sites = sites.slice(0, 16);
    var db = (typeof window !== 'undefined' && window.SITES_DB) || {};
    function entryFor(host) {
      var h = host;
      while (h) {
        if (db[h]) return db[h];
        var d = h.indexOf('.');
        if (d < 0) break;
        h = h.slice(d + 1);
      }
      return {};
    }
    for (var k = 0; k < sites.length; k++) {
      var clean = norm(sites[k].url);
      if (!clean) continue;
      var host = hostOf(clean);
      var st = entryFor(host);
      var cell = document.createElement('a');
      cell.className = 'site';
      cell.setAttribute('data-id', sites[k].id);
      cell.href = clean;
      cell.target = '_top';
      if (st.bg) cell.style.background = st.bg;
      var letter = document.createElement('span');
      letter.className = 'site-letter';
      letter.textContent = ((host.charAt(0) || '?')).toUpperCase();
      cell.appendChild(letter);
      island.appendChild(cell);
    }
  }
  function provFor(space) {
    try {
      return localStorage.getItem('focus:search:' + space)
        || localStorage.getItem('focus:search')
        || 'google';
    } catch (e) { return 'google'; }
  }
  function paintPlusGrid(slot) {
    // Провайдер — первым делом, пока краска не встала.
    try {
      var pi = slot.querySelector('[data-provider-icon]');
      if (pi) pi.src = provFor('focusplus') === 'yandex' ? 'icon/yandex.svg' : 'icon/google.svg';
    } catch (e) {}
    // Поиск выключен — прячем синхронно, чтобы не мигнул.
    try {
      var offPlus = false;
      try { offPlus = localStorage.getItem('focus:searchVis:focusplus') === '0'; } catch (e) {}
      if (offPlus) {
        var sbPlus = slot.querySelector('[data-search-box]');
        if (sbPlus) sbPlus.style.display = 'none';
      }
    } catch (e) {}
    var grid = slot.querySelector('[data-grid]');
    if (!grid || grid.children.length) return;
    function norm(v) {
      v = (v || '').trim();
      if (!v) return '';
      if (!/^[a-z]+:\/\//i.test(v)) v = 'https://' + v;
      if (/[\s<>]/.test(v)) return '';
      return /^https?:\/\/[^\/\s]+/.test(v) ? v : '';
    }
    function hostOf(url) {
      try { return new URL(url).hostname.replace(/^www\./, '').toLowerCase(); }
      catch (e) { return ''; }
    }
    function pretty(host, name) {
      if (name) return name;
      var first = (host.split('.')[0] || 'Сайт');
      return first.charAt(0).toUpperCase() + first.slice(1);
    }
    var db = (typeof window !== 'undefined' && window.SITES_DB) || {};
    var sites = null;
    try {
      var a = JSON.parse(localStorage.getItem('focus:sitesPlus'));
      if (Array.isArray(a)) {
        sites = a.filter(function (x) { return x && typeof x.id === 'string' && typeof x.url === 'string' && norm(x.url); });
        if (!sites.length) sites = null;
      }
    } catch (e) { sites = null; }
    if (!sites) return;
    sites = sites.slice(0, 72);
    for (var k = 0; k < sites.length; k++) {
      var clean = norm(sites[k].url);
      if (!clean) continue;
      var host = hostOf(clean);
      var st = {};
      var h = host;
      while (h) {
        if (db[h]) { st = db[h]; break; }
        var d = h.indexOf('.');
        if (d < 0) break;
        h = h.slice(d + 1);
      }
      var cell = document.createElement('a');
      cell.className = 'cell';
      cell.setAttribute('data-id', sites[k].id);
      cell.href = clean;
      cell.target = '_top';
      var icon = document.createElement('span');
      icon.className = 'cell-icon';
      if (st.bg) icon.style.background = st.bg;
      var letter = document.createElement('span');
      letter.className = 'cell-letter';
      letter.textContent = ((host.charAt(0) || '?')).toUpperCase();
      icon.appendChild(letter);
      cell.appendChild(icon);
      var nm = document.createElement('span');
      nm.className = 'cell-name';
      nm.textContent = pretty(host, sites[k].name).slice(0, 40);
      cell.appendChild(nm);
      grid.appendChild(cell);
    }
  }
  function paintSearchSnap(space) {
    var slot = null;
    var slots = document.querySelectorAll('.slot');
    for (var i = 0; i < slots.length; i++) {
      if (slots[i].getAttribute('data-space') === space) slot = slots[i];
    }
    if (!slot || slot.querySelector('[data-search-snap], iframe')) return;
    var p = provFor(space);
    var d = document.createElement('div');
    d.className = 'search-snap';
    d.setAttribute('data-search-snap', space);
    var loupe = document.createElement('img');
    loupe.className = 'loupe';
    loupe.alt = '';
    loupe.src = 'icon/lilac/search.svg';
    var pi = document.createElement('img');
    pi.className = 'prov';
    pi.alt = '';
    pi.setAttribute('data-provider-icon', '');
    pi.src = p === 'yandex' ? 'icon/yandex.svg' : 'icon/google.svg';
    var label = document.createElement('span');
    label.textContent = 'Поиск в интернете';
    d.appendChild(loupe);
    d.appendChild(pi);
    d.appendChild(label);
    slot.appendChild(d);
  }
})();
